﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class CTDonBanDAL
    {
        provider pr = new provider();
        public void them(CTDonBanDTO CT)
        {
            pr.thucthisql($"insert into CTDonBan values('{CT.Mactdb}','{CT.MaDB}',N'{CT.MaDia}',N'{CT.SoLuong}',{CT.DonGia},{CT.Tongtien})");
            pr.thucthisql($"UPDATE BangDia set SoLuong -= {CT.SoLuong} where MaDia='{CT.MaDia}'");

        }
        public void sua(CTDonBanDTO CT)
        {
            pr.thucthisql($"update CTDonBan set  MaDB='{CT.MaDB}', MaDia=N'{CT.MaDia}',SLBan=N'{CT.SoLuong}',DonGia={CT.DonGia},TongTien={CT.Tongtien} WHERE Mactdb='{CT.Mactdb}' ");
        }
        public void xoa(CTDonBanDTO CT,string ma)
        {
            pr.thucthisql($"delete from CTDonBan where Mactdb='{ma}'");
            pr.thucthisql($"UPDATE BangDia set SoLuong += {CT.SoLuong} where MaDia='{CT.MaDia}'");

        }
        public void tang(CTDonBanDTO CT, int a)
        {
            pr.thucthisql($"UPDATE BangDia set SoLuong += {a} where MaDia='{CT.MaDia}'");

        }
        public void giam(CTDonBanDTO CT, int a)
        {
            pr.thucthisql($"UPDATE BangDia set SoLuong -= {a} where MaDia='{CT.MaDia}'");

        }
        public DataTable top10()
        {
         return    pr.lay("SELECT TOP 10 MADia, SUM(SLBan) AS TotalSLBan FROM CTDonBan GROUP BY MaDia ORDER BY TotalSLBan DESC");
        }
    }
}
