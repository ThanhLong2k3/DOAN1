﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class CTDonNhapDAL
    {
        provider pr = new provider();
        public void them(CTDonNhapDTO CT)
        {
           
            pr.thucthisql($"insert into CTDonNhap values('{CT.Mactdn}','{CT.MaDN}',N'{CT.MaDia}',N'{CT.SoLuong}',{CT.Gianhap},{CT.Tongtien})");
            pr.thucthisql($"UPDATE BangDia set SoLuong += {CT.SoLuong} where MaDia='{CT.MaDia}'");


        }
        public void sua(CTDonNhapDTO CT)
        {
            pr.thucthisql($"update CTDonNhap set MaDN='{CT.MaDN}',MaDia=N'{CT.MaDia}',SLNhap=N'{CT.SoLuong}',DonGiaNhap='{CT.Gianhap}',TongTien={CT.Tongtien} WHERE  Mactdn='{CT.Mactdn}' ");
            
        }
        public void tang(CTDonNhapDTO CT,int a)
        {
            pr.thucthisql($"UPDATE BangDia set SoLuong += {a} where MaDia='{CT.MaDia}'");

        }
        public void giam(CTDonNhapDTO CT,int a)
        {
            pr.thucthisql($"UPDATE BangDia set SoLuong -= {a} where MaDia='{CT.MaDia}'");

        }
        public void xoa(string ma, CTDonNhapDTO CT)
        {
            pr.thucthisql($"delete from CTDonNhap where Mactdn='{ma}'");
            pr.thucthisql($"UPDATE BangDia set SoLuong -= {CT.SoLuong} where MaDia='{CT.MaDia}'");

        }
    }
}
