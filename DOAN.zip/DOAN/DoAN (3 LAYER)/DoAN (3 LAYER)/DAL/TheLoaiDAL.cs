﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class TheLoaiDAL
    {
        provider pr=new provider();
        public void Them(TheLoaiDTO TL)
        {
            pr.thucthisql($"insert into TheLoai values(N'{TL.MaTL}',N'{TL.TenTL}')");
        }
        public void Sua(TheLoaiDTO TL)
        {
            pr.thucthisql($"update TheLoai set TenTL=N'{TL.TenTL}' where MaTL=N'{TL.MaTL}'");
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"Delete from TheLoai where MaTL =N'{ma}'");
        }
       
    }
}
