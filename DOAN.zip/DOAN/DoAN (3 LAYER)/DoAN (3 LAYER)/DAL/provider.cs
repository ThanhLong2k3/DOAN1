﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;
using System.Drawing;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.ADO
{
    internal class provider
    {
        public SqlConnection con;
        public SqlCommand cmd;
        public SqlDataAdapter adapter;
        public DataTable dt;
        //public DataSet set;
        public SqlDataReader dr;
        private string chuoikn = @"Data Source=DESKTOP-CDO0SQ2\MSSQLSERVER01;Initial Catalog=DoAn2;Integrated Security=True";
        public void ketnoi()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        public void dongkn()
        {
            con = new SqlConnection(chuoikn);
            if (con.State == ConnectionState.Open)
                con.Close();
        }
        public void thucthisql(string sql)
        {
            {
                ketnoi();
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                dongkn();
            }
        }
        public int kiemtramatrung(string table,string colum,string ma)
        {
            int i;
            ketnoi();
            string sql = $"Select count(*) from {table} where {colum}='" + ma.Trim() + "'";
            cmd = new SqlCommand(sql, con);
            i = (int)(cmd.ExecuteScalar());
            dongkn();
            return i;
        }

        public DataTable tt(string colum,string table)
        {
            return lay($"select SUM({colum}) from {table} ");
        }
        public DataTable loadpkn(string columma, string table)
        {
            return lay($"Select * from {table}  ORDER BY {columma} ASC ");
        }

        public DataTable lay(string query)
        {
            ketnoi();
            adapter = new SqlDataAdapter(query, con);
            dt = new DataTable();
            adapter.Fill(dt);
            dongkn();
            return dt;
        }
        public int text(string table, string colum1, string namecot,string ma)
        {
            int i;
            ketnoi();
            string sql = $" select {colum1} from {table} where {namecot}='{ma}'";
            if (ma != "") {
                cmd = new SqlCommand(sql, con);
                i = (int)(cmd.ExecuteScalar());
                return i;
            }            
            else  i=0;
            dongkn();
            return i;
        }
        public string GIA(string colum1,string table,string namecot,string ma)
        {
            string i;
            ketnoi();
            string sql = $" select {colum1} from {table} where {namecot}='{ma}'";
            if (ma != "")
            {
                SqlCommand cmd = new SqlCommand(sql, con);
                i = cmd.ExecuteScalar().ToString();
                return i;
            }
            else  i = "";
            dongkn();
            return i;
        }
        public string tinhtongtheoma(string colum,string table,string namecot,string ma)
        {
            string i;
            ketnoi();
            string sql = $"select SUM({colum}) from {table} where {namecot}='{ma}'";
            if (ma != "")
            {
                SqlCommand cmd = new SqlCommand(sql, con);
                i = cmd.ExecuteScalar().ToString();
                return i;
            }
            else i = "";
            dongkn();
            return i;
        }
        public DataTable loadtable(string table)
        {
            return lay($"select * from {table}");
        }
        public DataTable TimKiem(string table, string colum1, string txt)
        {
            return    lay($"select*from {table} where {colum1} like '%{txt}%'  ");
        }
        public DataTable LoadCBB(string colum,string table)
        {
            return lay($"select {colum} from {table}");
        }
    
        public DataTable thongke(string tktheo,string ngay)
        {
            return lay($"SELECT DonBan.NgayBan, CT.MaDia,BD.TenDia, SUM(SLBan) AS SOLuong, SUM(TongTien) as Tien FROM CTDonBan CT INNER JOIN DonBan ON CT.MaDB=DonBan.MaDB inner join BangDia BD on CT.MaDia=BD.MaDia WHERE {tktheo}(NgayBan)='{ngay}' GROUP BY CT.MaDia ,BD.TenDia,DonBan.NgayBan");
        }
        public DataTable GetTop5MaDia(string tktheo, string ngay)
        {
            string query = $"select top 5  MaDia, SUM (SLBan) as SLBan from CTDonBan CT inner join DonBan  DB ON CT.MaDB=DB.MaDB WHERE {tktheo}(NgayBan)='{ngay}'  group by MaDia  ORDER BY SLBan DESC";
            return lay(query);
        }
    }
}
