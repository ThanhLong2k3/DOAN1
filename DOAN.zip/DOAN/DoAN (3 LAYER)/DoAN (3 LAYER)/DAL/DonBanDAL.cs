﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class DonBanDAL
    {
        provider pr = new provider();
        public void them(DonBanDTO DB)
        {
            string SQL=string.Format($"insert into DonBan values('{DB.MaDB}',N'{DB.MaNV}',N'{DB.MaKH}','{DB.NgayBan.ToString("yyyy-MM-dd")}',N'{DB.MaCK1}',{DB.Thanhtien})");
            pr.thucthisql(SQL);        
        }

        public void sua(DonBanDTO DB)
        {
            string sql = string.Format($"update DonBan set MaNV='{DB.MaNV}', MaKH='{DB.MaKH}',NgayBan='{DB.NgayBan.ToString("yyyy-MM-dd")}',MaCK='{DB.MaCK1}',ThanhTien={DB.Thanhtien} WHERE MaDB='{DB.MaDB}' ");
            pr.thucthisql(sql);
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"delete from DonBan where MaDB='{ma}'");
        }
    }
}
