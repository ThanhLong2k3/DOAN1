﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class NhaCCDAL
    {
        provider pr=new provider();
        public void them(NhaCCDTO CC)
        {
            pr.thucthisql($"insert into NhaCC values ('{CC.MaNCC}',N'{CC.HoTenCC}',N'{CC.DiaChicc}','{CC.SDTcc}' )");
        }
        public void sua(NhaCCDTO CC)
        {
            pr.thucthisql($"update NhaCC set HoTenNCC=N'{CC.HoTenCC}',DiaChiNCC=N'{CC.DiaChicc}',SDTNCC='{CC.SDTcc}' WHERE MaNCC='{CC.MaNCC}'");
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"delete from NhaCC where MaNCC='{ma}'");
        }
    }
}
