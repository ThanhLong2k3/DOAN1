﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DoAN__3_LAYER_.ADO
{
    internal class DonNhapDAL
    {
        provider pr=new provider();
        public void them(DonNhapDTO DN)
        {
            string sql = string.Format($"insert into DonNhap values('{DN.MaDN}','{DN.MaNV}','{DN.MaNCC}','{DN.NgayNhap.ToString("yyyy-MM-dd")}','{DN.NaCK}',{DN.ThanhTien1})");
            pr.thucthisql(sql);
        }
        public void sua(DonNhapDTO DN)
        {
            string sql = string.Format($"update DonNhap set MaNV='{DN.MaNV}',MaNCC='{DN.MaNCC}',NgayNhap='{DN.NgayNhap.ToString("yyyy-MM-dd")}',MaCK='{DN.NaCK}',ThanhTien={DN.ThanhTien1} where MaDN='{DN.MaDN}'");
            pr.thucthisql(sql);
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"delete from DonNhap where MaDN='{ma}'");
        }
    }
}
