﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace DoAN__3_LAYER_.ADO
{
    internal class NhanVienDAL
    {
        provider pr = new provider();
       public void them(NhanVienDTO NV)
        {
            string sql = string.Format($"insert into NhanVien values ('{NV.MaNV}','{NV.TenNV}','{NV.GT}','{NV.NgaySinh.ToString("yyyy-MM-dd")}','{NV.DiaChiNV}','{NV.Email}','{NV.SdtNV}') ");
            
            pr.thucthisql(sql);
        }
        public void sua(NhanVienDTO NV)
        {
            string sql = string.Format($"Update NhanVien set TenNV=N'{NV.TenNV}',GTNV=N'{NV.GT}',NgaySinh='{NV.NgaySinh.ToString("yyyy-MM-dd")}',DiaChi=N'{NV.DiaChiNV}',Email='{NV.Email}',SDTNV='{NV.SdtNV}'where MaNV='{NV.MaNV}'");

            pr.thucthisql(sql);
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"delete from NhanVien where MaNV='{ma}'");
        }
    }
}
