﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class ChietKhauDAL
    {
        provider pr = new provider();
        public void them(ChietKhauDTO CK)
        {
            pr.thucthisql($"insert into ChietKhau values('{CK.MaCK}',N'{CK.TenCK}')");
        }
        public void sua(ChietKhauDTO CK)
        {
            pr.thucthisql($"update ChietKhau set TenCK=N'{CK.TenCK}' WHERE MaCK='{CK.MaCK}' ");
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"delete from ChietKhau where MaCK='{ma}'");
        }
    }
}
