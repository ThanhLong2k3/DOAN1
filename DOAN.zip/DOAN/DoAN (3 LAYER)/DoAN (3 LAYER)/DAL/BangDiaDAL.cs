﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class BangDiaDAL
    {
        provider pr=new provider();
        public void Them(BangDiaDTO BD )
        {
    
            pr.thucthisql($"insert into BangDia values('{BD.MaDia}',N'{BD.TenDia}',N'{BD.MaTL}',{BD.SoLuong},{BD.DonGia})");
        }
        public void sua(BangDiaDTO BD)
        {
            pr.thucthisql($"update BangDia set TenDia=N'{BD.TenDia}',MaTL=N'{BD.MaTL}',SoLuong={BD.SoLuong},DonGia={BD.DonGia} where MaDia='{BD.MaDia}'");
        }
        public void Xoa(String MaDia)
        {
            pr.thucthisql($"Delete from BangDia where MaDia='{MaDia}'");
        }
       
    }
}
