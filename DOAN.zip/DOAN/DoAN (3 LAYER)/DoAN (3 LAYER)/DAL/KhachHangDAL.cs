﻿using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.ADO
{
    internal class KhachHangDAL
    {
        provider pr = new provider();
        public void Them(KhachHangDTO KH)
        {
            pr.thucthisql($"insert into KhachHang values(N'{KH.MaKH}',N'{KH.TenKH}',N'{KH.DiaChiKH}','{KH.EmailKH}','{KH.SdtKH}')");
        }
        public void Sua(KhachHangDTO KH)
        {
            pr.thucthisql($"update KhachHang set TenKH=N'{KH.TenKH}',DiaChiKH=N'{KH.DiaChiKH}',EmailKH=N'{KH.EmailKH}',SDTKH='{KH.SdtKH}' where MaKH=N'{KH.MaKH}'");
        }
        public void xoa(string ma)
        {
            pr.thucthisql($"Delete from KhachHang where MaKH =N'{ma}'");
        }
    }
}
