﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class DonBanBUS
    {
        provider pr = new provider();
        bool check(DonBanDTO DB)
        {
            bool mdb = DB.MaDB != "";
            bool mnv = DB.MaNV != "";
            bool mncc = DB.MaKH != "";

            if (mnv && mdb && mncc)
            { return true; }
            else return false;

        }
        public bool them(DonBanDTO DB)
        {
            if ((pr.kiemtramatrung("DonNhap", "MaDN", DB.MaDB) != 1) && check(DB) == true)
            {
                DonBanDAL db = new DonBanDAL();
                db.them(DB);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string MA)
        {
            bool check = MA != "";
            if (check)
            {
                DonBanDAL nv = new DonBanDAL();
                nv.xoa(MA);
                return true;
            }
            else return false;
        }
        public bool sua(DonBanDTO DB)
        {
            if (check(DB) == true)
            {
                DonBanDAL db = new DonBanDAL();
                db.sua(DB);
                return true;
            }
            else return false;
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string table, string colum1, string txt)
        {
            return pr.TimKiem(table, colum1, txt);
        }
        public DataTable loadpkn(string columma, string table)
        {
            return pr.loadpkn(columma, table);
        }
        public DataTable loadCBB(string colum, string table)
        {
            return pr.LoadCBB(colum, table);
        }
        public string sum_ma(string colum,string table,string namecot,string ma)
        {
            return pr.tinhtongtheoma(colum,table,namecot,ma);
        }
    }
}
