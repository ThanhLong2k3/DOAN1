﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class CTDonBanBUS
    {
        provider pr = new provider();
        bool check(CTDonBanDTO CTDB)
        {
            bool mmctdn = CTDB.Mactdb != "";
            bool mdb = CTDB.MaDB != "";
            bool md = CTDB.MaDia != "";
            bool sl = CTDB.SoLuong > 0;
            bool gi = CTDB.DonGia > 0;
            if (md && sl && mdb && gi && mmctdn)
            { return true; }
            else return false;

        }
        public DataTable top10()
        {
            CTDonBanDAL ctdb = new CTDonBanDAL();
           return ctdb.top10();
        }
        public bool them(CTDonBanDTO CTDB)
        {
            if (pr.kiemtramatrung("CTDonBan","Mactdb",CTDB.Mactdb)!=1 && check(CTDB) == true)
            {
                CTDonBanDAL ctdb = new CTDonBanDAL();
                ctdb.them(CTDB);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string ma, CTDonBanDTO CTDB)
        {
            bool check = ma != "";
            if (check)
            {
                CTDonBanDAL ctdb = new CTDonBanDAL();
                ctdb.xoa(CTDB,ma);
                return true;
            }
            else return false;
        }
        public bool sua(CTDonBanDTO CTDB)
        {
            if (check(CTDB) == true)
            {

                CTDonBanDAL db = new CTDonBanDAL();
                db.sua(CTDB);
                return true;
            }
            else return false;
        }
        public void tang(CTDonBanDTO ctdn, int a)
        {
            CTDonBanDAL CT = new CTDonBanDAL();
            CT.tang(ctdn, a);
        }
        public void giam(CTDonBanDTO ctdn, int a)
        {
            CTDonBanDAL CT = new CTDonBanDAL();
            CT.giam(ctdn, a);
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string table, string colum1, string txt)
        {
            return pr.TimKiem(table, colum1, txt);
        }
        public DataTable loadpkn(string columma, string table)
        {
            return pr.loadpkn(columma, table);
        }
        public DataTable loadCBB(string colum, string table)
        {
            return pr.LoadCBB(colum, table);
        }
        public int text(string table, string colum1, string name,string ma)
        {
            return pr.text(colum1, table,name, ma);
        }
        public string gia(string colum1,string table,string namecot,string ma)
        {
            return pr.GIA(colum1,table,namecot,ma);
        }
    }
}
