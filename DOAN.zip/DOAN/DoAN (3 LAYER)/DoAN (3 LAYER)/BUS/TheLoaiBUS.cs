﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class TheLoaiBUS
    {
        provider pr = new provider();
        public bool Check(TheLoaiDTO TL)
        {
            bool checkma = TL.MaTL != "";
            bool kttenTL=TL.TenTL!="";
            if ((pr.kiemtramatrung("TheLoai","MaTL", TL.MaTL) != 1)&& (kttenTL))
            {
               

                    TheLoaiDAL te = new TheLoaiDAL();
                    te.Them(TL);
                    return true;
                
            }
            else { return false; }
        }
        public bool xoa(string maTL)
        {
            bool checkmaTL=maTL!="";
            if(checkmaTL)
            {
                TheLoaiDAL te = new TheLoaiDAL();
                te.xoa(maTL);
                return true;
            }
            else return false;
        }
        public DataTable tim(string table,string colum,string txt)
        {
          return  pr.TimKiem(table,colum,txt);
        }
        public DataTable load(string  table)
        {
            return pr.loadtable("TheLoai");
        }
        public bool sua(TheLoaiDTO TL)
        {
            bool checkmaTL =TL.MaTL !="";
            bool checktenTL = TL.TenTL != "";

            if (checkmaTL&&checktenTL)
            {
                TheLoaiDAL te = new TheLoaiDAL();
                te.Sua(TL);
                return true;
            }
            else return false;
        }
    }
}
