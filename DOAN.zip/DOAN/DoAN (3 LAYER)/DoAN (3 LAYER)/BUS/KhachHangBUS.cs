﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.BUS
{
    internal class KhachHangBUS
    {
        provider pr = new provider();
        public bool them(KhachHangDTO KH)
        {
            bool ktten = KH.TenKH !="";
            bool ktdiachi = KH.DiaChiKH != "";

            bool CH = (KH.EmailKH.Contains("@"));
            if (CH == false) { MessageBox.Show("bạn cần nhập ký tự '@ trong email'"); }
            bool ktsdt = KH.SdtKH.Length==10;
            if ((pr.kiemtramatrung("KhachHang", "MaKH",KH.MaKH) != 1) && (ktten && ktdiachi &&CH && ktsdt))
            { 
                KhachHangDAL  kh= new KhachHangDAL();
                kh.Them(KH);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string makh)
        {
            bool checkmaTL = makh != "";
            if (checkmaTL)
            {
                KhachHangDAL kh = new KhachHangDAL();
                kh.xoa(makh);
                return true;
            }
            else return false;
        }
        public bool sua(KhachHangDTO KH)
        {
            bool ktten = KH.TenKH != "";
            bool ktdiachi = KH.DiaChiKH != "";

            bool CH = (KH.EmailKH.Contains("@"));
            if (CH == false) { MessageBox.Show("bạn cần nhập ký tự '@ trong email'"); }
            bool ktsdt = KH.SdtKH != "";

            if (ktten && ktdiachi && CH && ktsdt)
            {
                KhachHangDAL kh = new KhachHangDAL();

                kh.Sua(KH);
                return true;
            }
            else return false;
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string table,string colum1,string txt)
        {
            return pr.TimKiem(table, colum1, txt);
        }
        public DataTable loadpkn(string columma, string table)
        {
            return pr.loadpkn(columma, table);
        }
    }
}
