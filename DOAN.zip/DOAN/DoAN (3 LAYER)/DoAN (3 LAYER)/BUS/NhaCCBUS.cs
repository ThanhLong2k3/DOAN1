﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class NhaCCBUS
    {
        provider pr=new provider();
        public bool them(NhaCCDTO NCC)
        {
            bool checkma=NCC.MaNCC!="";
            bool checkten = NCC.HoTenCC != "";
            bool checkdc = NCC.DiaChicc != "";
            bool checksdt = NCC.SDTcc != "";
            if ((pr.kiemtramatrung("NhaCC", "MaNCC", NCC.MaNCC) != 1)&& checkdc&&checkma&&checkten&&checksdt)
            {
                NhaCCDAL ncc = new NhaCCDAL();
                ncc.them(NCC);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string ma)
        {
            bool checkma = ma != "";
            if (checkma)
            {
                NhaCCDAL nv = new NhaCCDAL();
                nv.xoa(ma);
                return true;
            }
            else return false;
        }
        public bool sua(NhaCCDTO NCC)
        {
            bool checkma = NCC.MaNCC != "";
            bool checkten = NCC.HoTenCC != "";
            bool checkdc = NCC.DiaChicc != "";
            bool checksdt = NCC.SDTcc != "";

            if (checkdc && checkma && checkten && checksdt)
            {

                NhaCCDAL ncc = new NhaCCDAL();
                ncc.sua(NCC);
                return true;
            }
            else return false;
        }
        public DataTable loadpkn(string table, string colma)
        {
            return pr.loadpkn(colma, table);
        }
        public DataTable timkiem(string table,string col ,string txt)
        {
            return pr.TimKiem(table, col, txt);
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
    }
}
