﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.BUS
{
    internal class NhanVienBUS
    {
        provider pr = new provider();
        public bool them(NhanVienDTO NV)
        {
            bool checksdt = NV.SdtNV.Length == 12;
            if (checksdt == false) { MessageBox.Show("bạn chưa nhập đủ số điện thoại! "); }
            bool CH = (NV.Email.Contains("@"));
            if (CH == false) { MessageBox.Show("bạn cần nhập ký tự '@ trong email'"); }
            
           
            if ((pr.kiemtramatrung("NhanVien","MaNV",NV.MaNV) != 1)&& CH && checksdt) 
            {
                NhanVienDAL nv = new NhanVienDAL();
                nv.them(NV);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string makh)
        {
            bool checkmaTL = makh != null;
            if (checkmaTL)
            {
                NhanVienDAL nv = new NhanVienDAL();
                nv.xoa(makh);
                return true;
            }
            else return false;
        }
        public bool sua(NhanVienDTO NV)
        {

            bool CH = (NV.Email.Contains("@"));
            if (CH == false) { MessageBox.Show("bạn cần nhập ký tự '@ trong email'"); }
            bool ktma = NV.MaNV != null;

            if (ktma)
            {

                NhanVienDAL nv = new NhanVienDAL();
                nv.sua(NV);
                return true;
            }
            else return false;
        }
     
        public DataTable loadpkn(string columma,string table)
        {
            return pr.loadpkn(columma, table);
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string txtsearch, string col1, string table)
        {
            return pr.TimKiem(table, col1, txtsearch);
        }
    }
}
