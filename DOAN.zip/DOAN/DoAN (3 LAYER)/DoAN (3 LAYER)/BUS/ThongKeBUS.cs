﻿using DoAN__3_LAYER_.ADO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.BUS
{
    internal class ThongKeBUS
    {
        provider pr=new provider();
        public DataTable thongke( string tktheo, string ngay) 
        {
            return pr.thongke(tktheo, ngay);
             }
        public DataTable GetTop5MaDia(string tktheo, string ngay)
        {
            return new provider().GetTop5MaDia(tktheo,ngay);
        }
    }
}
