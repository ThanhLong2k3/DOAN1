﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class DonNhapBUS
    {
        provider pr=new provider();
        bool check(DonNhapDTO DN)
        {
            bool mdn = DN.MaDN != "";
            bool mnv = DN.MaNV != "";
            bool mncc = DN.MaNCC != "";
            bool mck = DN.NaCK != "";
            if (mck && mnv && mdn && mncc && mck)
            { return true; }
            else return false;

        }
        public bool them(DonNhapDTO DN)
        {
            if ((pr.kiemtramatrung("DonNhap", "MaDN", DN.MaDN) != 1) && check(DN)==true)
            {
                DonNhapDAL dn = new DonNhapDAL();
                dn.them(DN);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string ma)
        {
            bool checkma = ma != null;
            if (checkma)
            {
                DonNhapDAL nv = new DonNhapDAL();
                nv.xoa(ma);
                return true;
            }
            else return false;
        }
        public bool sua(DonNhapDTO DN)
        {

           

            if (check(DN)==true)
            {

                DonNhapDAL dn = new DonNhapDAL();
                dn.sua(DN);
                return true;
            }
            else return false;
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string table, string colum1, string txt)
        {
            return pr.TimKiem(table, colum1, txt);
        }
        public DataTable loadpkn(string columma, string table)
        {
            return pr.loadpkn(columma, table);
        }
        public DataTable loadCBB(string colum, string table)
        {
            return pr.LoadCBB(colum, table);
        }
        public string sum_ma(string colum, string table, string namecot, string ma)
        {
            return pr.tinhtongtheoma(colum, table, namecot, ma);
        }
    }
}
