﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class BangDiaBUS
    {
        provider pr=new provider();
        public bool Them(BangDiaDTO BD )
        {
            
            bool checkTD = BD.TenDia !="";
            bool checkTL = BD.MaTL != "";
            bool checkSL = BD.SoLuong > 0 && BD.SoLuong.ToString() !="";
            bool checkdg = BD.DonGia > 0 && BD.DonGia.ToString() != "";
            if (pr.kiemtramatrung("BangDia","MaDia",BD.MaDia)!=1 && checkTD && checkTL && checkSL && checkdg)
            {
                BangDiaDAL bangdia = new BangDiaDAL();
                bangdia.Them(BD);
                return true;
            }
            else return false;
        }
        public bool sua(BangDiaDTO BD)
        {
            bool checkMaDia = BD.MaDia != "";
            bool checkTD = BD.TenDia != "";
            bool checkTL = BD.MaTL != "";
            bool checkSL = BD.SoLuong > 0;
            bool checkdg = BD.DonGia > 0;
            if (checkMaDia&&checkTD && checkTL && checkSL && checkdg)
            {
                BangDiaDAL bangdia = new BangDiaDAL();
                bangdia.sua(BD);
                return true;
            }
            else return false;
        }
      public DataTable tt(string colum,string table)
        {
            return    pr.tt(colum,table);
        }
        public bool xoa(string madia)
        {
           bool checkmadia=madia!="";
            if (checkmadia)
            {
                BangDiaDAL bangdia = new BangDiaDAL();
                bangdia.Xoa(madia);
                return true;
            }
            else return false;
        }
        public DataTable load(string table)
        {
           return pr.loadtable(table);
        }
        public DataTable timkiem(string txtsearch,string col1,string table)
        {
                return  pr.TimKiem(table,col1,txtsearch);
        }
       
    }
}
