﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class CTDonNhapBUS
    {
        provider pr = new provider();
        bool check(CTDonNhapDTO CTDN)
        {
            bool mmctdn = CTDN.Mactdn != "";
            bool mdn = CTDN.MaDia!= "";
            bool md = CTDN.MaDia != "";
            bool sl = CTDN.SoLuong >0;
            bool gi = CTDN.Gianhap>0;
            if (md && sl && mdn && gi&&mmctdn )
            { return true; }
            else return false;

        }
        public bool them(CTDonNhapDTO CTDN)
        {
            if (pr.kiemtramatrung("CTDonNhap","Mactdn",CTDN.Mactdn)!=1  && check(CTDN) == true)
            {
                CTDonNhapDAL ctdn = new CTDonNhapDAL();
                ctdn.them(CTDN);
                return true;

            }
            else { return false; }
        }
        public bool xoa(string ma, CTDonNhapDTO CTDN)
        {
            bool checkma = ma != null;
            if (checkma)
            {
                CTDonNhapDAL nv = new CTDonNhapDAL();
                nv.xoa(ma,CTDN);
                return true;
            }
            else return false;
        }
        public bool sua(CTDonNhapDTO CTDN)
        {



            if (check(CTDN) == true)
            {

                CTDonNhapDAL dn = new CTDonNhapDAL();
                dn.sua(CTDN);
                return true;
            }
            else return false;
        }
        public void tang(CTDonNhapDTO ctdn,int a)
        {
            CTDonNhapDAL CT=new CTDonNhapDAL();
            CT.tang(ctdn, a);
        }
        public void giam(CTDonNhapDTO ctdn,int a )
        {
            CTDonNhapDAL CT = new CTDonNhapDAL();
            CT.giam(ctdn,a);
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string table, string colum1, string txt)
        {
            return pr.TimKiem(table, colum1, txt);
        }
        public DataTable loadpkn(string columma, string table)
        {
            return pr.loadpkn(columma, table);
        }
        public DataTable loadCBB(string colum, string table)
        {
            return pr.LoadCBB(colum, table);
        }
      
        public int text(string table, string colum1, string name, string ma)
        {
            return pr.text(colum1, table, name, ma);
        }
        public string gia(string colum1, string table, string namecot, string ma)
        {
            return pr.GIA(colum1, table, namecot, ma);
        }
      
    }
}
