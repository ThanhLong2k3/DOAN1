﻿using DoAN__3_LAYER_.ADO;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.BUS
{
    internal class ChietKhauBUS
    {
        provider pr=new provider();
        public bool them(ChietKhauDTO CK)
        {
          
            if (pr.kiemtramatrung("ChietKhau", "MaCK", CK.MaCK) != 1 )
            {
                ChietKhauDAL ck = new ChietKhauDAL();
                ck.them(CK);
                return true;
            }
            else return false;
        }
        public bool sua(ChietKhauDTO CK)
        {
            bool checkma = CK.MaCK != "";
            bool checkten = CK.TenCK != "";
            if ( checkma && checkten)
            {
                ChietKhauDAL ck = new ChietKhauDAL();
                ck.sua(CK);
                return true;
            }
            else return false;
        }
        public DataTable tt(string colum, string table)
        {
            return pr.tt(colum, table);
        }
        public bool xoa(string ma)
        {
            bool checkma = ma != "";
            if (checkma)
            {
                ChietKhauDAL ck = new ChietKhauDAL();
                ck.xoa(ma);
                return true;
            }
            else return false;
        }
        public DataTable load(string table)
        {
            return pr.loadtable(table);
        }
        public DataTable timkiem(string txtsearch, string col1, string table)
        {
            return pr.TimKiem(table, col1, txtsearch);
        }
        public DataTable loadpkn(string columma,string table)
        {
            return pr.loadpkn(columma, table);
        }
    }
}
