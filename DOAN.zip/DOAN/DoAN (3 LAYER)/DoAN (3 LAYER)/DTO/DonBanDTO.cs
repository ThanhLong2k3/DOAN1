﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class DonBanDTO
    {
        private string maDB;
        private string maNV;
        private string maKH;
        private DateTime ngayBan;
        private string MaCK;
        private float thanhtien;

       
        public DonBanDTO() { }

        public DonBanDTO(string maDB, string maNV, string maKH, DateTime ngayBan, string maCK, float thanhtien)
        {
            this.MaDB = maDB;
            this.MaNV = maNV;
            this.MaKH = maKH;
            this.NgayBan = ngayBan;
            MaCK1 = maCK;
            this.Thanhtien = thanhtien;
        }

        public string MaDB { get => maDB; set => maDB = value; }
        public string MaNV { get => maNV; set => maNV = value; }
        public string MaKH { get => maKH; set => maKH = value; }
        public DateTime NgayBan { get => ngayBan; set => ngayBan = value; }
        public string MaCK1 { get => MaCK; set => MaCK = value; }
        public float Thanhtien { get => thanhtien; set => thanhtien = value; }
    }
}
