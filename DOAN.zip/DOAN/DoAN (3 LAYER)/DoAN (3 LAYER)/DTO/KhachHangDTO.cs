﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class KhachHangDTO
    {
        private string maKH;
        private string tenKH;
        private string diaChiKH;
        private string emailKH;
        private string sdtKH;

        public KhachHangDTO(string maKH, string tenKH, string diaChiKH, string emailKH, string sdtKH)
        {
            this.MaKH = maKH;
            this.TenKH = tenKH;
            this.DiaChiKH = diaChiKH;
            this.EmailKH = emailKH;
            this.SdtKH = sdtKH;
        }
        public KhachHangDTO() { }

        public string MaKH { get => maKH; set => maKH = value; }
        public string TenKH { get => tenKH; set => tenKH = value; }
        public string DiaChiKH { get => diaChiKH; set => diaChiKH = value; }
        public string EmailKH { get => emailKH; set => emailKH = value; }
        public string SdtKH { get => sdtKH; set => sdtKH = value; }
    }
}
