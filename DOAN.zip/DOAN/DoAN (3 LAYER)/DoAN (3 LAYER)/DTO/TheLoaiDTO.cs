﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class TheLoaiDTO
    {
        private string maTL;
        private string tenTL;

    
        public TheLoaiDTO() { }

        public TheLoaiDTO(string maTL, string tenTL)
        {
            this.MaTL = maTL;
            this.TenTL = tenTL;
        }

        public string MaTL { get => maTL; set => maTL = value; }
        public string TenTL { get => tenTL; set => tenTL = value; }
    }
}
