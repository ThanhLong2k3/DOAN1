﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class CTDonNhapDTO
    {
        private string mactdn;
        private string maDN;
        private string maDia;
        private int soLuong;
        private float gianhap;
        private float tongtien;

       
        public CTDonNhapDTO()
        { }

        public CTDonNhapDTO(string mactdn, string maDN, string maDia, int soLuong, float gianhap, float tongtien)
        {
            this.Mactdn = mactdn;
            this.MaDN = maDN;
            this.MaDia = maDia;
            this.SoLuong = soLuong;
            this.Gianhap = gianhap;
            this.Tongtien = tongtien;
        }

        public string Mactdn { get => mactdn; set => mactdn = value; }
        public string MaDN { get => maDN; set => maDN = value; }
        public string MaDia { get => maDia; set => maDia = value; }
        public int SoLuong { get => soLuong; set => soLuong = value; }
        public float Gianhap { get => gianhap; set => gianhap = value; }
        public float Tongtien { get => tongtien; set => tongtien = value; }
    }
}
