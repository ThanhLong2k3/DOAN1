﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class NhanVienDTO
    {
        private string maNV;
        private string tenNV;
        private string gT;
        private DateTime ngaySinh;
        private string diaChiNV;
        private string email;
        private string sdtNV;

        public NhanVienDTO(string maNV, string tenNV, string gT, DateTime ngaySinh, string diaChiNV, string email, string sdtNV)
        {
            this.MaNV = maNV;
            this.TenNV = tenNV;
            this.GT = gT;
            this.NgaySinh = ngaySinh;
            this.DiaChiNV = diaChiNV;
            this.Email = email;
            this.SdtNV = sdtNV;
        }
        public NhanVienDTO() { }
        public string MaNV { get => maNV; set => maNV = value; }
        public string TenNV { get => tenNV; set => tenNV = value; }
        public string GT { get => gT; set => gT = value; }
        public DateTime NgaySinh { get => ngaySinh; set => ngaySinh = value; }
        public string DiaChiNV { get => diaChiNV; set => diaChiNV = value; }
        public string Email { get => email; set => email = value; }
        public string SdtNV { get => sdtNV; set => sdtNV = value; }
    }
}
