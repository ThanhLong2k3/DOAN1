﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class BangDiaDTO
    {
        private string maDia;
        private string tenDia;
        private string maTL;
        private int soLuong;
        private float donGia;


        public BangDiaDTO(string maDia, string tenDia, string maTL, int soLuong, float donGia)
        {
            this.MaDia = maDia;
            this.TenDia = tenDia;
            this.MaTL = maTL;
            this.SoLuong = soLuong;
            this.DonGia = donGia;
        }

        public BangDiaDTO()
        {

        }
        public string MaDia { get => maDia; set => maDia = value; }
        public string TenDia { get => tenDia; set => tenDia = value; }
        public string MaTL { get => maTL; set => maTL = value; }
        public int SoLuong { get => soLuong; set => soLuong = value; }
        public float DonGia { get => donGia; set => donGia = value; }
    }
}
