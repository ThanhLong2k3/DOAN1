﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class CTDonBanDTO
    {
        private string mactdb;
        private string maDB;
        private string maDia;
        private int soLuong;
        private float donGia;
        private float tongtien;

       
        public CTDonBanDTO() { }

        public CTDonBanDTO(string mactdb, string maDB, string maDia, int soLuong, float donGia, float tongtien)
        {
            this.Mactdb = mactdb;
            this.MaDB = maDB;
            this.MaDia = maDia;
            this.SoLuong = soLuong;
            this.DonGia = donGia;
            this.Tongtien = tongtien;
        }

        public string Mactdb { get => mactdb; set => mactdb = value; }
        public string MaDB { get => maDB; set => maDB = value; }
        public string MaDia { get => maDia; set => maDia = value; }
        public int SoLuong { get => soLuong; set => soLuong = value; }
        public float DonGia { get => donGia; set => donGia = value; }
        public float Tongtien { get => tongtien; set => tongtien = value; }
    }
}
