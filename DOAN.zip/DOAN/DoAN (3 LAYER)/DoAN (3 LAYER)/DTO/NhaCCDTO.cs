﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class NhaCCDTO
    {
        private string maNCC;
        private string hoTenCC;
        private string diaChicc;
        private string sDTcc;

    
        public NhaCCDTO() { }

        public NhaCCDTO(string maNCC, string hoTenCC, string diaChicc, string sDTcc)
        {
            this.MaNCC = maNCC;
            this.HoTenCC = hoTenCC;
            this.DiaChicc = diaChicc;
            this.SDTcc = sDTcc;
        }

        public string MaNCC { get => maNCC; set => maNCC = value; }
        public string HoTenCC { get => hoTenCC; set => hoTenCC = value; }
        public string DiaChicc { get => diaChicc; set => diaChicc = value; }
        public string SDTcc { get => sDTcc; set => sDTcc = value; }
    }
}
