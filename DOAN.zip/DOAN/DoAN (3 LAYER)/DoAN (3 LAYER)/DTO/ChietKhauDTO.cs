﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAN__3_LAYER_.DTO
{
    internal class ChietKhauDTO
    {
        private string maCK;
        private string tenCK;

        public ChietKhauDTO(string maCK, string tenCK)
        {
            this.MaCK = maCK;
            this.TenCK = tenCK;
        }
        public ChietKhauDTO(){}

        public string MaCK { get => maCK; set => maCK = value; }
        public string TenCK { get => tenCK; set => tenCK = value; }
    }
}
