﻿
using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmBangDiaGUI : Form
    {
        public frmBangDiaGUI()
        {
            InitializeComponent();
            load();

        }
        BangDiaDTO BD = new BangDiaDTO();
        BangDiaBUS BUS=new BangDiaBUS();
       
        private void btnThem_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = BUS.Them(BD);
            if (kt)
            {
                MessageBox.Show("Thêm sản phẩm thành công ! ");
                dgvBangDia.DataSource = BUS.load("BangDia"); // refresh datagridview
                lammoi();

            }
            else
            {
                MessageBox.Show("Sản Phẩm Đã Tồn tại hoặc bạn chưa điền tên sản phẩm ! ");
            }
        }
        public void lammoi()
        {
            txtMaDia.Text="";
            cbbTL.Text="";
            txtTenDia.Text="";
            txtSoLuong.Text="0";
            txtDonGia.Text = "0";
            txtMaDia.Enabled = true;
        }
        void bien()
        {
            BD.MaDia = txtMaDia.Text;
            BD.MaTL = cbbTL.Text;
            BD.TenDia = txtTenDia.Text;
            if (txtDonGia.Text != "" && txtSoLuong.Text != "")
            {
                BD.SoLuong = int.Parse(txtSoLuong.Text);
                BD.DonGia = float.Parse(txtDonGia.Text);
        }
            else
            {
                txtDonGia.Text = "0"; txtSoLuong.Text = "0";
                BD.SoLuong = int.Parse(txtSoLuong.Text);
                BD.DonGia = float.Parse(txtDonGia.Text);
             }

        }
        void load()
        {
            DataTable dt = BUS.load("TheLoai");
            foreach (DataRow item in dt.Rows)
            {
                cbbTL.Items.Add(item["MaTL"]);
            }

        }

        private void frmBangDiaGUI_Load(object sender, EventArgs e)
        {
            dgvBangDia.DataSource = BUS.load("BangDia");
        }

        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            string ma = txtMaDia.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa sản phẩm này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = BUS.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa sản phẩm Thành Công !");
                    dgvBangDia.DataSource = BUS.load("BangDia");// refresh datagridview
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa sản phẩm thất bại !");

            }
        }
        
            private void btnSua_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = BUS.sua(BD);
            if (kt)
            {
                MessageBox.Show("sửa sản phẩm thành công ! ");
                dgvBangDia.DataSource = BUS.load("BangDia");// refresh datagridview
                lammoi();

            }
            else
            {
                MessageBox.Show("thông tin sản phẩm chưa đc sửa ! ");
            }
        }

        private void dgvBangDia_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMaDia.Text= dgvBangDia[0, i].Value.ToString();
            txtTenDia.Text= dgvBangDia[1, i].Value.ToString();
            cbbTL.Text= dgvBangDia[2, i].Value.ToString();
            txtSoLuong.Text= dgvBangDia[3, i].Value.ToString();
            txtDonGia.Text= dgvBangDia[4, i].Value.ToString();
            txtMaDia.Enabled = false;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
             string ma = txtMaDia.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa sản phẩm này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = BUS.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa sản phẩm Thành Công !");
                    dgvBangDia.DataSource = BUS.load("BangDia"); // refresh datagridview
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa sản phẩm thất bại !");

            }
        }

       

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            lammoi();
        }

     

       

        

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvBangDia.DataSource = BUS.timkiem("BangDia","MaDia",txtsearch.Text);
            dgvBangDia.Refresh();
            if(txtsearch.Text=="")
            {
                dgvBangDia.DataSource = BUS.load("BangDia"); // refresh datagridview

            }
        }
        public void chinhapso(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }

        private void txtDonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }
    }
}
