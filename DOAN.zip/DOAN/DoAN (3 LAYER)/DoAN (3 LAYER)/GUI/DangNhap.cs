﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
            txtMK.UseSystemPasswordChar = !txtMK.UseSystemPasswordChar;

        }
        private void Dangnhap()
        {
            string tk = txtTK.Text.Trim();
            string mk=txtMK.Text.Trim();
            if(tk=="admin".Trim() && mk=="admin".Trim())
            {
                MessageBox.Show("Đăng nhập thành công !");
                frmMeNuGUI mn=new frmMeNuGUI();
                this.Hide();
                mn.Show();
            }
            else
            {
                MessageBox.Show(" tên đăng nhập hoặc mật khẩu không đúng! ");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dangnhap();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked==true)
            {
                txtMK.UseSystemPasswordChar = !txtMK.UseSystemPasswordChar;
            }
            if (checkBox1.Checked == false) { 
                txtMK.UseSystemPasswordChar = !txtMK.UseSystemPasswordChar;
            }
        }
    }
}
