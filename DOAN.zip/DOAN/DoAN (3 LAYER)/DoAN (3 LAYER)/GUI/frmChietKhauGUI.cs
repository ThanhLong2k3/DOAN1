﻿using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmChietKhauGUI : Form
    {
        public frmChietKhauGUI()
        {
            InitializeComponent();
        }
        ChietKhauDTO CK=new ChietKhauDTO();
        ChietKhauBUS bus=new ChietKhauBUS();
        void lammoi()
        {
            foreach (Control ctrl in TT1.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TT1.Enabled = true;
            txtMaLoai.Enabled = true;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string ma = txtMaLoai.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa chiết khấu này  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa chết khấu Thành Công !");
                    dgvCK.DataSource = bus.load("ChietKhau"); 
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa chiết khấu thất bại !");

            }
        }

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            BIEN();


            bool kt = bus.them(CK);
            if (kt)
            {
                MessageBox.Show("Thêm chiết khấu thành công ! ");
                dgvCK.DataSource = bus.load("ChietKhau");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã nhân viên  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
            }
        }
        void BIEN()
        {
            CK.MaCK = txtMaLoai.Text;
            CK.TenCK=txtTenLoai.Text;
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            BIEN();
            bool kt = bus.sua(CK);
            if (kt)
            {
                MessageBox.Show("sửa chiết khấu thành công ! ");
                dgvCK.DataSource = bus.load("ChietKhau");
                lammoi();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }
      
       void loadpikn()
            {

                dgvCK.DataSource = bus.loadpkn("MaCK", "ChietKhau");
                dgvCK.Columns[0].HeaderText = "Mã chiết khấu";
                dgvCK.Columns[1].HeaderText = "Tên chiết khấu";
            }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvCK.DataSource = bus.timkiem("ChietKhau", "MaCK", txtsearch.Text);
            dgvCK.Refresh();
            if (txtsearch.Text == "")
            {
                dgvCK.DataSource = bus.load("ChietKhau"); // refresh datagridview

            }
        }

        private void frmChietKhauGUI_Load(object sender, EventArgs e)
        {
            loadpikn();
            dgvCK.DataSource = bus.load("ChietKhau");
        }

        private void dgvCK_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMaLoai.Text = dgvCK[0, i].Value.ToString();
            txtTenLoai.Text = dgvCK[1, i].Value.ToString();
        }
    }
}
