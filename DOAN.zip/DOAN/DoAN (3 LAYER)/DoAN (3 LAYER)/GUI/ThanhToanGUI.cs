﻿using DoAN__3_LAYER_.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class ThanhToanGUI : Form
    {
        public ThanhToanGUI()
        {
            InitializeComponent();
            loadKH();
        }
        CTDonBanBUS ct=new CTDonBanBUS();
        void loadKH()
        {
           dgvkh.DataSource= ct.load("KhachHang");
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
