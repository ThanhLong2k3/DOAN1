﻿namespace DoAN__3_LAYER_.GUI
{
    partial class frmHoaDonNhapGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHoaDonNhapGUI));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnlmDB = new System.Windows.Forms.Button();
            this.buttbtndeleDB = new System.Windows.Forms.Button();
            this.btnfixDB = new System.Windows.Forms.Button();
            this.btnaddDB = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dgvDonNhap = new System.Windows.Forms.DataGridView();
            this.TTDB = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btntimten = new System.Windows.Forms.Button();
            this.txtthanhtien = new System.Windows.Forms.TextBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.cbbMaNCC = new System.Windows.Forms.ComboBox();
            this.cbbMaNV = new System.Windows.Forms.ComboBox();
            this.cbbMaCK = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMaDN = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.slcu = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnlammoiCT = new System.Windows.Forms.Button();
            this.btnXoaCT = new System.Windows.Forms.Button();
            this.btnSuaCT = new System.Windows.Forms.Button();
            this.btnThemCT = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvCTDonNhap = new System.Windows.Forms.DataGridView();
            this.TTCT = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.slcon = new System.Windows.Forms.Label();
            this.txtmact = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txttongtien = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.cbbMaDB = new System.Windows.Forms.ComboBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.cbbMaDia = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonNhap)).BeginInit();
            this.TTDB.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTDonNhap)).BeginInit();
            this.TTCT.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1621, 478);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.groupBox4);
            this.panel4.Controls.Add(this.groupBox5);
            this.panel4.Controls.Add(this.TTDB);
            this.panel4.Location = new System.Drawing.Point(3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(605, 457);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.Turquoise;
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(3, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(599, 46);
            this.panel5.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(200, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(213, 26);
            this.label4.TabIndex = 19;
            this.label4.Text = "Quản Lý Đơn Nhập";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.btnlmDB);
            this.groupBox4.Controls.Add(this.buttbtndeleDB);
            this.groupBox4.Controls.Add(this.btnfixDB);
            this.groupBox4.Controls.Add(this.btnaddDB);
            this.groupBox4.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox4.Location = new System.Drawing.Point(3, 372);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(599, 82);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Danh sách chức năng";
            // 
            // btnlmDB
            // 
            this.btnlmDB.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnlmDB.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlmDB.ForeColor = System.Drawing.Color.Black;
            this.btnlmDB.Image = ((System.Drawing.Image)(resources.GetObject("btnlmDB.Image")));
            this.btnlmDB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlmDB.Location = new System.Drawing.Point(28, 26);
            this.btnlmDB.Name = "btnlmDB";
            this.btnlmDB.Size = new System.Drawing.Size(98, 43);
            this.btnlmDB.TabIndex = 6;
            this.btnlmDB.Text = "Làm mới";
            this.btnlmDB.UseVisualStyleBackColor = false;
            this.btnlmDB.Click += new System.EventHandler(this.btnlmDB_Click);
            // 
            // buttbtndeleDB
            // 
            this.buttbtndeleDB.BackColor = System.Drawing.Color.Tomato;
            this.buttbtndeleDB.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttbtndeleDB.ForeColor = System.Drawing.Color.Black;
            this.buttbtndeleDB.Image = ((System.Drawing.Image)(resources.GetObject("buttbtndeleDB.Image")));
            this.buttbtndeleDB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttbtndeleDB.Location = new System.Drawing.Point(491, 25);
            this.buttbtndeleDB.Name = "buttbtndeleDB";
            this.buttbtndeleDB.Size = new System.Drawing.Size(87, 46);
            this.buttbtndeleDB.TabIndex = 9;
            this.buttbtndeleDB.Text = "Xóa";
            this.buttbtndeleDB.UseVisualStyleBackColor = false;
            this.buttbtndeleDB.Click += new System.EventHandler(this.buttbtndeleDB_Click);
            // 
            // btnfixDB
            // 
            this.btnfixDB.BackColor = System.Drawing.Color.MediumPurple;
            this.btnfixDB.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfixDB.ForeColor = System.Drawing.Color.Black;
            this.btnfixDB.Image = ((System.Drawing.Image)(resources.GetObject("btnfixDB.Image")));
            this.btnfixDB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfixDB.Location = new System.Drawing.Point(339, 25);
            this.btnfixDB.Name = "btnfixDB";
            this.btnfixDB.Size = new System.Drawing.Size(91, 44);
            this.btnfixDB.TabIndex = 8;
            this.btnfixDB.Text = "Sửa";
            this.btnfixDB.UseVisualStyleBackColor = false;
            this.btnfixDB.Click += new System.EventHandler(this.btnfixDB_Click);
            // 
            // btnaddDB
            // 
            this.btnaddDB.BackColor = System.Drawing.Color.YellowGreen;
            this.btnaddDB.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddDB.ForeColor = System.Drawing.Color.Black;
            this.btnaddDB.Image = ((System.Drawing.Image)(resources.GetObject("btnaddDB.Image")));
            this.btnaddDB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnaddDB.Location = new System.Drawing.Point(181, 27);
            this.btnaddDB.Name = "btnaddDB";
            this.btnaddDB.Size = new System.Drawing.Size(104, 43);
            this.btnaddDB.TabIndex = 7;
            this.btnaddDB.Text = "Thêm";
            this.btnaddDB.UseVisualStyleBackColor = false;
            this.btnaddDB.Click += new System.EventHandler(this.btnaddDB_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.dgvDonNhap);
            this.groupBox5.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox5.Location = new System.Drawing.Point(3, 52);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(387, 321);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Danh sách đơn Nhập";
            // 
            // dgvDonNhap
            // 
            this.dgvDonNhap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDonNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDonNhap.BackgroundColor = System.Drawing.Color.White;
            this.dgvDonNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDonNhap.Location = new System.Drawing.Point(0, 19);
            this.dgvDonNhap.Name = "dgvDonNhap";
            this.dgvDonNhap.RowHeadersVisible = false;
            this.dgvDonNhap.Size = new System.Drawing.Size(381, 289);
            this.dgvDonNhap.TabIndex = 11;
            this.dgvDonNhap.TabStop = false;
            this.dgvDonNhap.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDonNhap_CellClick);
            // 
            // TTDB
            // 
            this.TTDB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TTDB.Controls.Add(this.label14);
            this.TTDB.Controls.Add(this.txtsearch);
            this.TTDB.Controls.Add(this.btntimten);
            this.TTDB.Controls.Add(this.txtthanhtien);
            this.TTDB.Controls.Add(this.dtpDate);
            this.TTDB.Controls.Add(this.cbbMaNCC);
            this.TTDB.Controls.Add(this.cbbMaNV);
            this.TTDB.Controls.Add(this.cbbMaCK);
            this.TTDB.Controls.Add(this.label7);
            this.TTDB.Controls.Add(this.label8);
            this.TTDB.Controls.Add(this.label9);
            this.TTDB.Controls.Add(this.txtMaDN);
            this.TTDB.Controls.Add(this.label10);
            this.TTDB.Controls.Add(this.label11);
            this.TTDB.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTDB.ForeColor = System.Drawing.Color.SteelBlue;
            this.TTDB.Location = new System.Drawing.Point(393, 61);
            this.TTDB.Name = "TTDB";
            this.TTDB.Size = new System.Drawing.Size(209, 312);
            this.TTDB.TabIndex = 15;
            this.TTDB.TabStop = false;
            this.TTDB.Text = "Thông Tin Đơn Nhập";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(12, 240);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 17);
            this.label14.TabIndex = 17;
            this.label14.Text = "Thành Tiền";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(101, 276);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(99, 23);
            this.txtsearch.TabIndex = 16;
            this.txtsearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearch_KeyUp);
            // 
            // btntimten
            // 
            this.btntimten.BackColor = System.Drawing.Color.White;
            this.btntimten.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimten.ForeColor = System.Drawing.Color.Black;
            this.btntimten.Image = ((System.Drawing.Image)(resources.GetObject("btntimten.Image")));
            this.btntimten.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btntimten.Location = new System.Drawing.Point(6, 270);
            this.btntimten.Name = "btntimten";
            this.btntimten.Size = new System.Drawing.Size(68, 36);
            this.btntimten.TabIndex = 15;
            this.btntimten.Text = "Tìm Kiếm";
            this.btntimten.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btntimten.UseVisualStyleBackColor = false;
            // 
            // txtthanhtien
            // 
            this.txtthanhtien.Location = new System.Drawing.Point(102, 236);
            this.txtthanhtien.Name = "txtthanhtien";
            this.txtthanhtien.Size = new System.Drawing.Size(99, 23);
            this.txtthanhtien.TabIndex = 5;
            // 
            // dtpDate
            // 
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(103, 159);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(97, 23);
            this.dtpDate.TabIndex = 3;
            // 
            // cbbMaNCC
            // 
            this.cbbMaNCC.FormattingEnabled = true;
            this.cbbMaNCC.Location = new System.Drawing.Point(103, 113);
            this.cbbMaNCC.Name = "cbbMaNCC";
            this.cbbMaNCC.Size = new System.Drawing.Size(97, 25);
            this.cbbMaNCC.TabIndex = 2;
            // 
            // cbbMaNV
            // 
            this.cbbMaNV.FormattingEnabled = true;
            this.cbbMaNV.Location = new System.Drawing.Point(102, 69);
            this.cbbMaNV.Name = "cbbMaNV";
            this.cbbMaNV.Size = new System.Drawing.Size(98, 25);
            this.cbbMaNV.TabIndex = 1;
            // 
            // cbbMaCK
            // 
            this.cbbMaCK.FormattingEnabled = true;
            this.cbbMaCK.Location = new System.Drawing.Point(103, 198);
            this.cbbMaCK.Name = "cbbMaCK";
            this.cbbMaCK.Size = new System.Drawing.Size(97, 25);
            this.cbbMaCK.TabIndex = 4;
            this.cbbMaCK.SelectedIndexChanged += new System.EventHandler(this.cbbMaCK_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 14);
            this.label7.TabIndex = 9;
            this.label7.Text = "Mã Chiết khấu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(6, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 14);
            this.label8.TabIndex = 7;
            this.label8.Text = "Ngày Nhập";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 14);
            this.label9.TabIndex = 5;
            this.label9.Text = "Mã Nhân Viên";
            // 
            // txtMaDN
            // 
            this.txtMaDN.Location = new System.Drawing.Point(103, 22);
            this.txtMaDN.Name = "txtMaDN";
            this.txtMaDN.Size = new System.Drawing.Size(97, 23);
            this.txtMaDN.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(-5, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 14);
            this.label10.TabIndex = 3;
            this.label10.Text = "Mã  Nhà Cung Cấp";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(6, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 14);
            this.label11.TabIndex = 1;
            this.label11.Text = "Mã Đơn Nhập";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.TTCT);
            this.panel2.Location = new System.Drawing.Point(614, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(668, 457);
            this.panel2.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Turquoise;
            this.panel3.Controls.Add(this.slcu);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(2, -4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(667, 50);
            this.panel3.TabIndex = 26;
            // 
            // slcu
            // 
            this.slcu.AutoSize = true;
            this.slcu.ForeColor = System.Drawing.Color.Black;
            this.slcu.Location = new System.Drawing.Point(554, 19);
            this.slcu.Name = "slcu";
            this.slcu.Size = new System.Drawing.Size(45, 13);
            this.slcu.TabIndex = 20;
            this.slcu.Text = "mã ctdb";
            this.slcu.Visible = false;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(236, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 26);
            this.label3.TabIndex = 19;
            this.label3.Text = "Chi Tiết Đơn Nhập";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.btnlammoiCT);
            this.groupBox3.Controls.Add(this.btnXoaCT);
            this.groupBox3.Controls.Add(this.btnSuaCT);
            this.groupBox3.Controls.Add(this.btnThemCT);
            this.groupBox3.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox3.Location = new System.Drawing.Point(4, 375);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(664, 82);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách chức năng";
            // 
            // btnlammoiCT
            // 
            this.btnlammoiCT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnlammoiCT.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnlammoiCT.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlammoiCT.ForeColor = System.Drawing.Color.Black;
            this.btnlammoiCT.Image = ((System.Drawing.Image)(resources.GetObject("btnlammoiCT.Image")));
            this.btnlammoiCT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlammoiCT.Location = new System.Drawing.Point(6, 20);
            this.btnlammoiCT.Name = "btnlammoiCT";
            this.btnlammoiCT.Size = new System.Drawing.Size(97, 43);
            this.btnlammoiCT.TabIndex = 5;
            this.btnlammoiCT.Text = "Làm mới";
            this.btnlammoiCT.UseVisualStyleBackColor = false;
            this.btnlammoiCT.Click += new System.EventHandler(this.btnlammoiCT_Click);
            // 
            // btnXoaCT
            // 
            this.btnXoaCT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnXoaCT.BackColor = System.Drawing.Color.Tomato;
            this.btnXoaCT.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaCT.ForeColor = System.Drawing.Color.Black;
            this.btnXoaCT.Image = ((System.Drawing.Image)(resources.GetObject("btnXoaCT.Image")));
            this.btnXoaCT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoaCT.Location = new System.Drawing.Point(507, 21);
            this.btnXoaCT.Name = "btnXoaCT";
            this.btnXoaCT.Size = new System.Drawing.Size(87, 46);
            this.btnXoaCT.TabIndex = 8;
            this.btnXoaCT.Text = "Xóa";
            this.btnXoaCT.UseVisualStyleBackColor = false;
            this.btnXoaCT.Click += new System.EventHandler(this.btnXoaCT_Click);
            // 
            // btnSuaCT
            // 
            this.btnSuaCT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSuaCT.BackColor = System.Drawing.Color.MediumPurple;
            this.btnSuaCT.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaCT.ForeColor = System.Drawing.Color.Black;
            this.btnSuaCT.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaCT.Image")));
            this.btnSuaCT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSuaCT.Location = new System.Drawing.Point(337, 21);
            this.btnSuaCT.Name = "btnSuaCT";
            this.btnSuaCT.Size = new System.Drawing.Size(103, 44);
            this.btnSuaCT.TabIndex = 7;
            this.btnSuaCT.Text = "Sửa";
            this.btnSuaCT.UseVisualStyleBackColor = false;
            this.btnSuaCT.Click += new System.EventHandler(this.btnSuaCT_Click);
            // 
            // btnThemCT
            // 
            this.btnThemCT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnThemCT.BackColor = System.Drawing.Color.YellowGreen;
            this.btnThemCT.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemCT.ForeColor = System.Drawing.Color.Black;
            this.btnThemCT.Image = ((System.Drawing.Image)(resources.GetObject("btnThemCT.Image")));
            this.btnThemCT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemCT.Location = new System.Drawing.Point(180, 21);
            this.btnThemCT.Name = "btnThemCT";
            this.btnThemCT.Size = new System.Drawing.Size(98, 43);
            this.btnThemCT.TabIndex = 6;
            this.btnThemCT.Text = "Thêm";
            this.btnThemCT.UseVisualStyleBackColor = false;
            this.btnThemCT.Click += new System.EventHandler(this.btnThemCT_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dgvCTDonNhap);
            this.groupBox2.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox2.Location = new System.Drawing.Point(2, 57);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(420, 319);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách CT đơn nhập";
            // 
            // dgvCTDonNhap
            // 
            this.dgvCTDonNhap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCTDonNhap.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCTDonNhap.BackgroundColor = System.Drawing.Color.White;
            this.dgvCTDonNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCTDonNhap.Location = new System.Drawing.Point(0, 14);
            this.dgvCTDonNhap.Name = "dgvCTDonNhap";
            this.dgvCTDonNhap.RowHeadersVisible = false;
            this.dgvCTDonNhap.Size = new System.Drawing.Size(414, 283);
            this.dgvCTDonNhap.TabIndex = 11;
            this.dgvCTDonNhap.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCTDonNhap_CellClick);
            // 
            // TTCT
            // 
            this.TTCT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TTCT.Controls.Add(this.label13);
            this.TTCT.Controls.Add(this.slcon);
            this.TTCT.Controls.Add(this.txtmact);
            this.TTCT.Controls.Add(this.label12);
            this.TTCT.Controls.Add(this.txttongtien);
            this.TTCT.Controls.Add(this.txtSoLuong);
            this.TTCT.Controls.Add(this.cbbMaDB);
            this.TTCT.Controls.Add(this.txtDonGia);
            this.TTCT.Controls.Add(this.cbbMaDia);
            this.TTCT.Controls.Add(this.label6);
            this.TTCT.Controls.Add(this.label5);
            this.TTCT.Controls.Add(this.label2);
            this.TTCT.Controls.Add(this.label1);
            this.TTCT.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TTCT.ForeColor = System.Drawing.Color.SteelBlue;
            this.TTCT.Location = new System.Drawing.Point(418, 61);
            this.TTCT.Name = "TTCT";
            this.TTCT.Size = new System.Drawing.Size(192, 319);
            this.TTCT.TabIndex = 15;
            this.TTCT.TabStop = false;
            this.TTCT.Text = "Thông tin ct đơn nhập";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calisto MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(10, 237);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 17);
            this.label13.TabIndex = 21;
            this.label13.Text = "Tổng Tiền";
            // 
            // slcon
            // 
            this.slcon.AutoSize = true;
            this.slcon.ForeColor = System.Drawing.Color.Black;
            this.slcon.Location = new System.Drawing.Point(182, 178);
            this.slcon.Name = "slcon";
            this.slcon.Size = new System.Drawing.Size(21, 17);
            this.slcon.TabIndex = 20;
            this.slcon.Text = "M";
            this.slcon.Visible = false;
            // 
            // txtmact
            // 
            this.txtmact.Location = new System.Drawing.Point(89, 20);
            this.txtmact.Name = "txtmact";
            this.txtmact.Size = new System.Drawing.Size(94, 23);
            this.txtmact.TabIndex = 18;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(15, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 14);
            this.label12.TabIndex = 19;
            this.label12.Text = "mã ctdn";
            // 
            // txttongtien
            // 
            this.txttongtien.Enabled = false;
            this.txttongtien.Location = new System.Drawing.Point(88, 235);
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.Size = new System.Drawing.Size(92, 23);
            this.txttongtien.TabIndex = 4;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(88, 156);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(94, 23);
            this.txtSoLuong.TabIndex = 1;
            this.txtSoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuong_KeyPress);
            this.txtSoLuong.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSoLuong_KeyUp);
            // 
            // cbbMaDB
            // 
            this.cbbMaDB.FormattingEnabled = true;
            this.cbbMaDB.Location = new System.Drawing.Point(88, 61);
            this.cbbMaDB.Name = "cbbMaDB";
            this.cbbMaDB.Size = new System.Drawing.Size(94, 25);
            this.cbbMaDB.TabIndex = 0;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Enabled = false;
            this.txtDonGia.Location = new System.Drawing.Point(88, 195);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(94, 23);
            this.txtDonGia.TabIndex = 3;
            this.txtDonGia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDonGia_KeyPress);
            // 
            // cbbMaDia
            // 
            this.cbbMaDia.FormattingEnabled = true;
            this.cbbMaDia.Location = new System.Drawing.Point(88, 110);
            this.cbbMaDia.Name = "cbbMaDia";
            this.cbbMaDia.Size = new System.Drawing.Size(94, 25);
            this.cbbMaDia.TabIndex = 2;
            this.cbbMaDia.SelectedIndexChanged += new System.EventHandler(this.cbbMaDia_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(14, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 14);
            this.label6.TabIndex = 9;
            this.label6.Text = "Đơn Gía";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(16, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 14);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mã Đĩa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(14, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "Số Lượng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calisto MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(9, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã Đơn Nhập";
            // 
            // frmHoaDonNhapGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1296, 475);
            this.Controls.Add(this.panel1);
            this.Name = "frmHoaDonNhapGUI";
            this.Text = "frmHoaDonNhapGUI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmHoaDonNhapGUI_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDonNhap)).EndInit();
            this.TTDB.ResumeLayout(false);
            this.TTDB.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTDonNhap)).EndInit();
            this.TTCT.ResumeLayout(false);
            this.TTCT.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnlmDB;
        private System.Windows.Forms.Button buttbtndeleDB;
        private System.Windows.Forms.Button btnfixDB;
        private System.Windows.Forms.Button btnaddDB;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dgvDonNhap;
        private System.Windows.Forms.GroupBox TTDB;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btntimten;
        private System.Windows.Forms.TextBox txtthanhtien;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.ComboBox cbbMaNCC;
        private System.Windows.Forms.ComboBox cbbMaNV;
        private System.Windows.Forms.ComboBox cbbMaCK;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMaDN;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label slcu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnlammoiCT;
        private System.Windows.Forms.Button btnXoaCT;
        private System.Windows.Forms.Button btnSuaCT;
        private System.Windows.Forms.Button btnThemCT;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvCTDonNhap;
        private System.Windows.Forms.GroupBox TTCT;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label slcon;
        private System.Windows.Forms.TextBox txtmact;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txttongtien;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.ComboBox cbbMaDB;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.ComboBox cbbMaDia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}