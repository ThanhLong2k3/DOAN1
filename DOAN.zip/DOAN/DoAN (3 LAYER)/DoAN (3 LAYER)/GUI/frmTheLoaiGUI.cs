﻿
using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmTheLoaiGUI : Form
    {
        public frmTheLoaiGUI()
        {
            InitializeComponent();
        }
        TheLoaiDTO TL = new TheLoaiDTO();
        TheLoaiBUS TheLoai = new TheLoaiBUS();
        private void lammoi()
        {
            txtMaLoai.Text = "";
            txtTenLoai.Text = "";
            txtMaLoai.Enabled = true;
        }
        private void btnThem_Click_1(object sender, EventArgs e)
        {
           
            TL.MaTL=txtMaLoai.Text;
            TL.TenTL=txtTenLoai.Text;
            
            bool kt = TheLoai.Check(TL);
            if (kt)
            {
                MessageBox.Show("Thêm Thể Loại thành công ! ");
                dgvTL.DataSource = TheLoai.load("TheLoai"); // refresh datagridview
                lammoi();

            }
            else
            {
                MessageBox.Show("Thể Loại Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");

            }
        }

        private void frmTheLoaiGUI_Load(object sender, EventArgs e)
        {
           
             dgvTL.DataSource = TheLoai.load("TheLoai"); // refresh datagridview

        }


        private void dgvTL_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMaLoai.Text = dgvTL[0, i].Value.ToString();
            txtTenLoai.Text = dgvTL[1, i].Value.ToString();
            txtMaLoai.Enabled = false;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
           
            string maTL = txtMaLoai.Text;
           
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa Thể loại này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = TheLoai.xoa(maTL);
                if (kt)
                {
                    MessageBox.Show("Xóa Thể Loại Thành Công !");
                    dgvTL.DataSource = TheLoai.load("TheLoai"); // refresh datagridview
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa Thể Loại thất bại !");

            }
        }

        private void btnSua_Click_1(object sender, EventArgs e)
        {
            TL.MaTL = txtMaLoai.Text;
            TL.TenTL = txtTenLoai.Text;
            bool kt = TheLoai.sua(TL);
            if (kt)
            {
                MessageBox.Show(" Sửa sữ liệu thành công !");
                dgvTL.DataSource = TheLoai.load("TheLoai"); // refresh datagridvie
                lammoi();

            }
            else
                MessageBox.Show(" Sửa sữ liệu thất bại !");


        }

        private void btnThoat_Click_1(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }

        }

        

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvTL.DataSource = TheLoai.tim("TheLoai", "MaTL", txtsearch.Text);
            dgvTL.Refresh();
            if (txtsearch.Text == "")
            {
                dgvTL.DataSource = TheLoai.load("TheLoai");

            }
        
        }
    }
}

