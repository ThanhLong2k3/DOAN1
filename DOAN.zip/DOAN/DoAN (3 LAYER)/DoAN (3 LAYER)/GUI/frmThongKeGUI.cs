﻿using DoAN__3_LAYER_.BUS;
using System;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmThongKeGUI : Form
    {
        public frmThongKeGUI()
        {
            InitializeComponent();
        }
        ThongKeBUS bus = new ThongKeBUS();
        private void cbbtk_SelectedIndexChanged(object sender, EventArgs e)
        {

            string a = cbbtk.SelectedItem.ToString().Trim().ToLower();

            if (txtngay.Text == "")
            {

            }
            if (a == "Ngày".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Ngày";
                txtlc.Text = "Nhập Ngày: ";

            }
            else if (a == "Thàng".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Tháng";
                txtlc.Text = "Nhập Tháng: ";


            }
            else if (a == "Năm".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Năm";

                txtlc.Text = "Nhập Năm: ";

            }
        }

        private void txtngay_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtngay.Text == "") { btnThongke.Enabled = false; }
            else
            {
                btnThongke.Enabled = true;
            }
        }
        void duadl()
        {
            chart1.Series.Clear();
            chart1.Series.Add("Số lượng");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            duadl();
            string tk;
            int ngay = int.Parse(txtngay.Text);
            if (txtngay.Text == "")
            {
                txtngay.Text = "1";
            }
            else
            {
                switch (txtlc.Text)
                {

                    case "Nhập Ngày: ":
                        {
                            tk = "Day";
                            if (ngay > 0 && ngay <= 31)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show("Bạn nhập ngày không dúng vui lòng nhập lại! "); }
                            break;
                        }
                    case "Nhập Tháng: ":
                        {
                            tk = "month";
                            if (ngay > 0 && ngay <= 12)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show("Bạn nhập tháng không dúng vui lòng nhập lại! "); }
                            break;
                        }
                    case "Nhập Năm: ":
                        {
                            tk = "year";
                            string c = DateTime.Now.Year.ToString();
                            if (ngay > 2000 && ngay <= DateTime.Now.Year)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show($"Bạn nhập Năm không hợp lệ vui lòng nhập lại!  2000< năm < {c} "); }
                            break;
                        }
                }
            }
        }

        private void frmThongKeGUI_Load(object sender, EventArgs e)
        {

        }
    }
}
