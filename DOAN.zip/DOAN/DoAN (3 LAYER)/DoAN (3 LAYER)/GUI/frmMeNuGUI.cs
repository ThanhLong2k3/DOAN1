﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmMeNuGUI : Form
    {
        public frmMeNuGUI()
        {
            InitializeComponent();
          
        }
        private Form KhoiTaoFormCon;
        private void MoFormCon(Form FormCon)
        {
            if (KhoiTaoFormCon != null)
            {
                KhoiTaoFormCon.Close();
            }
            KhoiTaoFormCon = FormCon;
            FormCon.TopLevel = false;
            FormCon.FormBorderStyle = FormBorderStyle.None;
            FormCon.Dock = DockStyle.Fill;
            dgformcon.Controls.Add(FormCon);
            dgformcon.Tag = FormCon;
            FormCon.BringToFront();
            FormCon.Show();
        }

        public void an()
        {

            if (panel3.Visible == false)
            {
                panel3.Visible = true;
              
            }
            else
            {
                panel3.Visible = false;
             
            }

        }






        private void btnBangDia_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmBangDiaGUI());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            an();
        }

        private void btnNV_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmNhanVienGUI());
        }

        private void btnNhaCC_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmNhaCCGUI());
        }



        private void btnKhachHang_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmKhachHangGUI());
        }

        private void btnCK_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmChietKhauGUI());
        }

        void tt()
        {
            if (HD.Visible == false)
            {
                HD.Visible = true;
            }
            else
            {
                HD.Visible = false;
            }
        }
        private void btnTT_Click(object sender, EventArgs e)
        {
            tt();
        }

        private void btnHDN_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmHoaDonNhapGUI());
        }

        private void btnHDB_Click(object sender, EventArgs e)
        {
            MoFormCon(new HoaDonBanGUI());
        }

        private void btnTheLoai_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmTheLoaiGUI());
        }

        private void panel6_Click(object sender, EventArgs e)
        {
            if (pmenu.Visible == false)
            { pmenu.Visible = true;
                
            }
            else
            {
                pmenu.Visible = false;
           
            }
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            MoFormCon(new frmThongKe1UI());
        }
    }
}
