﻿using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmHoaDonNhapGUI : Form
    {
        public frmHoaDonNhapGUI()
        {
            InitializeComponent();
        }
        DonNhapDTO DN = new DonNhapDTO();
        DonNhapBUS bus = new DonNhapBUS();
        void lammoi()
        {
            foreach (Control ctrl in TTDB.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TTDB.Enabled = true;
            txtMaDN.Enabled = true;
        }
        private void loaddn()
        {
            dgvDonNhap.DataSource = bus.load("DonNhap");
        }
        string tk; string ck;

        private void dgvDonNhap_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            DataGridViewRow row = dgvDonNhap.Rows[e.RowIndex];
            tk = row.Cells[0].Value.ToString();
            ck = row.Cells[4].Value.ToString();
            thanhtien(tk, ck);
            dgvCTDonNhap.DataSource = bus.timkiem("CTDonNhap", "MaDN", tk);
            txtMaDN.Text = dgvDonNhap[0, i].Value.ToString();
            cbbMaNV.Text = dgvDonNhap[1, i].Value.ToString();
            cbbMaNCC.Text = dgvDonNhap[2, i].Value.ToString();
            dtpDate.Text = dgvDonNhap[3, i].Value.ToString();
            cbbMaCK.Text = dgvDonNhap[4, i].Value.ToString();
            txtthanhtien.Text = dgvDonNhap[5, i].Value.ToString();
            txtMaDN.Enabled = false;
        }

        private void btnlmDB_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void buttbtndeleDB_Click(object sender, EventArgs e)
        {
            string ma = txtMaDN.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa đơn Nhập  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {

                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa Đơn Nhập Thành Công !");
                    loaddn();
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa Đơn Bán thất bại !");

            }
        }
        private void bien()
        {
            DN.MaDN = txtMaDN.Text;
            DN.MaNV = cbbMaNV.Text;
            DN.MaNCC = cbbMaNCC.Text;
            DN.NgayNhap = DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd"));
            DN.NaCK = cbbMaCK.Text;
            DN.ThanhTien1 = float.Parse(txtthanhtien.Text);
        }
        void loaddnpikn()
        {

            dgvDonNhap.DataSource = bus.loadpkn("MaDN", "DonNhap");
            dgvDonNhap.Columns[0].HeaderText = "Mã đơn Nhập";
            dgvDonNhap.Columns[1].HeaderText = "Mã Nhân viên";
            dgvDonNhap.Columns[2].HeaderText = "Mã NCC";
            dgvDonNhap.Columns[3].HeaderText = "Ngày Nhập";
            dgvDonNhap.Columns[4].HeaderText = "Mã chiết khấu";
            dgvDonNhap.Columns[5].HeaderText = "Thành Tiền";

        }

        private void btnaddDB_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.them(DN);
            if (kt)
            {
                MessageBox.Show("Thêm Đơn Nhập thành công ! ");
                dgvDonNhap.DataSource = bus.load("DonNhap");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã Đơn Nhập  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
            }
        }

        private void btnfixDB_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.sua(DN);
            if (kt)
            {
                MessageBox.Show("sửa đơn Nhập thành công ! ");
                loaddn();
                lammoi();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }
        void LoadMANV()
        {
            DataTable dt = bus.loadCBB("MaNV", "NhanVien");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaNV.Items.Add(item["MaNV"]);
            }
        }
        void LoadMANCC()
        {
            DataTable dt = bus.loadCBB("MaNCC", "NhaCC");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaNCC.Items.Add(item["MaNCC"]);
            }
        }
        void LoadMACK()
        {
            DataTable dt = bus.loadCBB("MaCK", "ChietKhau");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaCK.Items.Add(item["MaCK"]);
            }
        }
        private void thanhtien(string ma, string ck)
        {
            string tien = bus.sum_ma("TongTien", "CTDonNhap", "MaDN", ma);
            if (tien == "")
            {
                tien = "0";
            }
            if (ck == "5%")
            {
                double b = double.Parse(tien) * (1 - 0.05);
                txtthanhtien.Text = b.ToString();
            }
            else if (ck == "10%")
            {
                double b = double.Parse(tien) * (1 - 0.1);
                txtthanhtien.Text = b.ToString();
            }
            else if (ck == "15%")
            {
                double b = double.Parse(tien) * (1 - 0.15);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "20%")
            {
                double b = double.Parse(tien) * (1 - 0.2);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "25%")
            {
                double b = double.Parse(tien) * (1 - 0.25);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "30%")
            {
                double b = double.Parse(tien) * (1 - 0.3);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "50%")
            {
                double b = double.Parse(tien) * (1 - 0.5);
                txtthanhtien.Text = b.ToString(); ;
            }
            else
            {
                double b = double.Parse(tien);
                txtthanhtien.Text = b.ToString();
            }
        }

     

        private void cbbMaCK_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = txtMaDN.Text;
            string ck = cbbMaCK.SelectedItem.ToString().Trim();
            thanhtien(a, ck);
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvDonNhap.DataSource = bus.timkiem("DonNhap", "MaDN", txtsearch.Text);
            dgvDonNhap.Refresh();
            if (txtsearch.Text == "")
            {
                loaddn();
            }
        }
        private void frmHoaDonNhapGUI_Load(object sender, EventArgs e)
        {
            loaddn(); loaddnpikn(); LoadMACK(); LoadMANCC(); LoadMANV();
            //===========
            loadctpikn();LoadMADia();LoadMADN();loadctdn();
        }
        //=================================================================================
        CTDonNhapDTO ct = new CTDonNhapDTO();
        CTDonNhapBUS busct = new CTDonNhapBUS();
        void loadctpikn()
        {

            dgvCTDonNhap.DataSource = bus.loadpkn("Mactdb", "CTDonBan");
            dgvCTDonNhap.Columns[0].HeaderText = "Mã  ct đơn Bán";
            dgvCTDonNhap.Columns[1].HeaderText = "Mã Đơn Bán";
            dgvCTDonNhap.Columns[2].HeaderText = "Mã Đĩa";
            dgvCTDonNhap.Columns[3].HeaderText = "Số Lượng Bán";
            dgvCTDonNhap.Columns[4].HeaderText = "Đơn giá Bán";
            dgvCTDonNhap.Columns[5].HeaderText = "Tổng Tiền";

        }
        void lammoict()
        {
            foreach (Control ctrl in TTCT.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TTCT.Enabled = true;
            txtmact.Enabled = true;
        }
        void bienct()
        {
            ct.Mactdn = txtmact.Text;
            ct.MaDN = cbbMaDB.Text;
            ct.MaDia = cbbMaDia.Text;
            ct.SoLuong = int.Parse(txtSoLuong.Text);
            ct.Gianhap = float.Parse(txtDonGia.Text);
            ct.Tongtien = float.Parse(txttongtien.Text);
        }

        private void btnThemCT_Click(object sender, EventArgs e)
        {
            bienct();
            bool kt = busct.them(ct);
            if (int.Parse(txtSoLuong.Text) < int.Parse(slcon.Text))
            {
                if (kt)
                {
                    MessageBox.Show("Thêm chi tiết Đơn nhập thành công ! ");
                    loadctdn();
                    lammoict();
                }
                else
                {
                    MessageBox.Show("mã Đơn nhập  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
                }
            }
            else
                MessageBox.Show("Số lượng hàng trong kho không đủ ! ");
        }

        private void btnlammoiCT_Click(object sender, EventArgs e)
        {
            lammoict();
        }
        private void loadctdn()
        {
            dgvCTDonNhap.DataSource = busct.load("CTDonNhap");

        }

        private void btnSuaCT_Click(object sender, EventArgs e)
        {
            bienct();
            bool kt = busct.sua(ct);

            if (kt)
            {
                tinhtoan(int.Parse(slcu.Text), int.Parse(txtSoLuong.Text));
                MessageBox.Show("sửa chi tiết đơn nhập thành công ! ");
                loadctdn();
                lammoict();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }

        private void btnXoaCT_Click(object sender, EventArgs e)
        {
            bienct();
            string ma = txtmact.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa đơn nhập này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = busct.xoa(ma, ct);
                if (kt)
                {
                    MessageBox.Show("Xóa Đơn nhập  Thành Công !");
                    loadctdn();
                    lammoict();

                }
                else
                    MessageBox.Show("Xóa Đơn bán thất bại !");
            }
        }

        private void dgvCTDonNhap_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            DataGridViewRow row = dgvCTDonNhap.Rows[e.RowIndex];
            string ma = row.Cells[2].Value.ToString();
            loadslcon(ma);
            txtmact.Text = dgvCTDonNhap[0, i].Value.ToString();
            cbbMaDB.Text = dgvCTDonNhap[1, i].Value.ToString();
            cbbMaDia.Text = dgvCTDonNhap[2, i].Value.ToString();
            txtSoLuong.Text = dgvCTDonNhap[3, i].Value.ToString();
            txtDonGia.Text = dgvCTDonNhap[4, i].Value.ToString();
            txttongtien.Text = dgvCTDonNhap[5, i].Value.ToString();
            loadslcu();
            txtmact.Enabled = false;
        }
        void LoadMADia()
        {
            DataTable dt = busct.loadCBB("MaDia", "BangDia");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaDia.Items.Add(item["MaDia"]);
            }
        }
        void LoadMADN()
        {
            DataTable dt = busct.loadCBB("MaDN", "DonNhap");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaDB.Items.Add(item["MaDN"]);
                cbbMaDB.Refresh();
            }
        }
        void loadslcu()
        {
            int dt = busct.text("SLNhap", "CTDonNhap", "Mactdn", txtmact.Text);
            slcu.Text = dt.ToString();
        }
        void loadslcon(string a)
        {
            string dt = busct.gia("SoLuong", "BangDia", "MaDia", a);
            slcon.Text = dt.ToString();
        }
        public void tinhtoan(int a, int b)
        {
            int c;
            if (a > b)
            {
                c = a - b;
               
                busct.giam(ct, c);
            }
            else if (a < b)
            {
                c = b - a;
                busct.tang(ct, c);
            }

        }

        private void cbbMaDia_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = cbbMaDia.SelectedItem.ToString();
            string dt = busct.gia("Dongia", "BangDia", "MaDia", a);
            txtDonGia.Text = dt.ToString();
            loadslcon(a);
        }

        private void txtSoLuong_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSoLuong.Text == "")
            {

            }
            else
            {
                int a = int.Parse(txtSoLuong.Text);
                int b = int.Parse(txtDonGia.Text);
                int kq = a * b;
                txttongtien.Text = kq.ToString();
            }
        }
        public void chinhapso(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }

        private void txtDonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }
    }
}
