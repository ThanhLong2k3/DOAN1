﻿using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class HoaDonBanGUI : Form
    {
        public HoaDonBanGUI()
        {
            InitializeComponent();
        }

        DonBanDTO DB = new DonBanDTO();
        DonBanBUS bus = new DonBanBUS();
        void lammoi()
        {
            foreach (Control ctrl in TTDB.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TTDB.Enabled = true;
            txtMaDB.Enabled = true;
        }
        private void loaddb()
        {
            dgvDonBan.DataSource = bus.load("DonBan");
        }
        string tk; string ck;
        private void dgvDonBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            DataGridViewRow row = dgvDonBan.Rows[e.RowIndex];
            tk = row.Cells[0].Value.ToString();
            ck = row.Cells[4].Value.ToString();
            thanhtien(tk,ck);
            dgvCTDonBan.DataSource = bus.timkiem("CTDonBan", "MaDB", tk);
            txtMaDB.Text = dgvDonBan[0, i].Value.ToString();
            cbbMaNV.Text = dgvDonBan[1, i].Value.ToString();
            cbbMaKH.Text = dgvDonBan[2, i].Value.ToString();
            dtpDate.Text = dgvDonBan[3, i].Value.ToString();
            cbbMaCK.Text = dgvDonBan[4, i].Value.ToString();
            txtthanhtien.Text = dgvDonBan[5, i].Value.ToString();
            txtMaDB.Enabled = false;
        }

        private void btnlmDB_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void buttbtndeleDB_Click(object sender, EventArgs e)
        {
            string ma = txtMaDB.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa đơn Bán  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {

                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa Đơn Bán  Thành Công !");
                    dgvDonBan.DataSource = bus.load("DonBan");
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa Đơn Bán thất bại !");

            }
        }
        private void bien()
        {
            DB.MaDB = txtMaDB.Text;
            DB.MaNV = cbbMaNV.Text;
            DB.MaKH = cbbMaKH.Text;
            DB.NgayBan = DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd"));
            DB.MaCK1 = cbbMaCK.Text;          
            DB.Thanhtien = float.Parse(txtthanhtien.Text);
        }
        void loaddnpikn()
        {

            dgvDonBan.DataSource = bus.loadpkn("MaDB", "DonBan");
            dgvDonBan.Columns[0].HeaderText = "Mã đơn Bán";
            dgvDonBan.Columns[1].HeaderText = "Mã Nhân viên";
            dgvDonBan.Columns[2].HeaderText = "Mã Khách hàng";
            dgvDonBan.Columns[3].HeaderText = "Ngày bán";
            dgvDonBan.Columns[4].HeaderText = "Mã chiết khấu";
            dgvDonBan.Columns[5].HeaderText = "Thành Tiền";

        }

        private void btnaddDB_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.them(DB);
            if (kt)
            {
                MessageBox.Show("Thêm Đơn Bán thành công ! ");
                dgvDonBan.DataSource = bus.load("DonBan");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã Đơn Bán  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
            }
        }

        private void btnfixDB_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.sua(DB);
            if (kt)
            {
                MessageBox.Show("sửa đơn Bán thành công ! ");
                loaddb();
                lammoi();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }
        void LoadMANV()
        {
            DataTable dt = bus.loadCBB("MaNV", "NhanVien");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaNV.Items.Add(item["MaNV"]);
            }
            //cbbMaNV.DataSource=  bus.load("NhanVien");
            //  cbbMaNV.DisplayMember = "TenNV";
            //  cbbMaNV.ValueMember = "MaNV";
        }
        void LoadMAKH()
        {
            DataTable dt = bus.loadCBB("MaKH", "KhachHang");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaKH.Items.Add(item["MaKH"]);
            }
        }
        void LoadMACK()
        {
            DataTable dt = bus.loadCBB("MaCK", "ChietKhau");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaCK.Items.Add(item["MaCK"]);
            }
        }

        private void HoaDonBanGUI_Load(object sender, EventArgs e)
        {
            LoadMACK();loaddb();loaddnpikn();LoadMAKH();LoadMANV();
            //------------------------
            loadctpikn(); loadctdb(); LoadMADia(); LoadMADN();
        }
        //==========================================================================================================================
        CTDonBanDTO ct = new CTDonBanDTO();
        CTDonBanBUS busct = new CTDonBanBUS();
        void loadctpikn()
        {

            dgvCTDonBan.DataSource = bus.loadpkn("Mactdb", "CTDonBan");
            dgvCTDonBan.Columns[0].HeaderText = "Mã  ct đơn Bán";
            dgvCTDonBan.Columns[1].HeaderText = "Mã Đơn Bán";
            dgvCTDonBan.Columns[2].HeaderText = "Mã Đĩa";
            dgvCTDonBan.Columns[3].HeaderText = "Số Lượng Bán";
            dgvCTDonBan.Columns[4].HeaderText = "Đơn giá Bán";
        }
        void lammoict()
        {
            foreach (Control ctrl in TTCT.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TTCT.Enabled = true;
            txtmact.Enabled = true;
        }
        void bienct()
        {
            ct.Mactdb = txtmact.Text;
            ct.MaDB = cbbMaDB.Text;
            ct.MaDia = cbbMaDia.Text;
            ct.SoLuong = int.Parse(txtSoLuong.Text);
            ct.DonGia = float.Parse(txtDonGia.Text);
            ct.Tongtien = float.Parse(txttongtien.Text);
        }

        private void btnThemCT_Click(object sender, EventArgs e)
        {
            bienct();
            bool kt = busct.them(ct);
            if (int.Parse(txtSoLuong.Text) < int.Parse(slcon.Text))
            {
                if (kt)
                {
                    MessageBox.Show("Thêm chi tiết Đơn bán thành công ! ");
                    loadctdb();
                    lammoict();
                }
                else
                {
                    MessageBox.Show("mã Đơn bán  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
                }
            }
            else
                MessageBox.Show("Số lượng hàng trong kho không đủ ! ");
            
        }

        private void btnlammoiCT_Click(object sender, EventArgs e)
        {
            lammoict();
        }
        private void loadctdb()
        {
            dgvCTDonBan.DataSource = busct.load("CTDonBan");
           
        }

        private void btnSuaCT_Click(object sender, EventArgs e)
        {
            bienct();
            bool kt = busct.sua(ct);

            if (kt)
            {
                tinhtoan(int.Parse(slcu.Text), int.Parse(txtSoLuong.Text));
                MessageBox.Show("sửa chi tiết đơn Bán thành công ! ");
                loadctdb();
                lammoict();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }

        private void btnXoaCT_Click(object sender, EventArgs e)
        {
            bienct();
            string ma = txtmact.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa đơn Bán này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = busct.xoa(ma,ct);
                if (kt)
                {
                    MessageBox.Show("Xóa Đơn bán  Thành Công !");
                    loadctdb();
                    lammoict();

                }
                else
                    MessageBox.Show("Xóa Đơn bán thất bại !");
            }
        }

        private void dgvCTDonBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            DataGridViewRow row = dgvCTDonBan.Rows[e.RowIndex];
            string ma = row.Cells[2].Value.ToString();
            loadslcon(ma);
            txtmact.Text = dgvCTDonBan[0, i].Value.ToString();
            cbbMaDB.Text = dgvCTDonBan[1,i].Value.ToString();
            cbbMaDia.Text = dgvCTDonBan[2, i].Value.ToString();
            txtSoLuong.Text = dgvCTDonBan[3, i].Value.ToString();
            txtDonGia.Text = dgvCTDonBan[4, i].Value.ToString();
            txttongtien.Text = dgvCTDonBan[5, i].Value.ToString();
            loadslcu();
            txtmact.Enabled = false;
        }
        void LoadMADia()
        {
            DataTable dt = busct.loadCBB("MaDia", "BangDia");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaDia.Items.Add(item["MaDia"]);
            }
        }
        void LoadMADN()
        {
            DataTable dt = busct.loadCBB("MaDB", "DonBan");
            foreach (DataRow item in dt.Rows)
            {
                cbbMaDB.Items.Add(item["MaDB"]);
                cbbMaDB.Refresh();
            }
        }
        void loadslcu()
        {
            int dt = busct.text("SLBan", "CTDonBan", "Mactdb", txtmact.Text);

            slcu.Text = dt.ToString();
        }
        void loadslcon(string a)
        {
            string dt = busct.gia("SoLuong", "BangDia", "MaDia", a);
            slcon.Text = dt.ToString();
        }
        public void tinhtoan(int a, int b)
        {
            int c;
            if (a > b)
            {
                c = a - b;
                busct.tang(ct, c);
            }
            else if (a < b)
            {
                c = b - a;
                busct.giam(ct, c);

            }

        }

        private void cbbMaDia_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = cbbMaDia.SelectedItem.ToString();
            string dt = busct.gia("Dongia","BangDia","MaDia", a);
            txtDonGia.Text = dt.ToString();
            loadslcon(a);
        }

        private void txtSoLuong_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSoLuong.Text == "")
            {

            }
            else
            {
                int a = int.Parse(txtSoLuong.Text);
                int b = int.Parse(txtDonGia.Text);
                int kq = a * b;
                txttongtien.Text = kq.ToString();
            }
        }

       
        private void thanhtien(string ma,string ck)
        {
            string tien = bus.sum_ma("TongTien", "CTDonBan", "MaDB", ma);
            if(tien=="")
            {
                tien = "0";
            }
            if (ck == "5%")
            {
                double b = double.Parse(tien) * (1 - 0.05);
                txtthanhtien.Text = b.ToString();
            }
            else if (ck == "10%")
            {
                double b = double.Parse(tien) * (1 - 0.1);
                txtthanhtien.Text = b.ToString();
            }
            else if (ck == "15%")
            {
                double b = double.Parse(tien) * (1 - 0.15);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "20%")
            {
                double b = double.Parse(tien) * (1 - 0.2);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "25%")
            {
                double b = double.Parse(tien) * (1 - 0.25);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "30%")
            {
                double b = double.Parse(tien) * (1 - 0.3);
                txtthanhtien.Text = b.ToString(); ;
            }
            else if (ck == "50%")
            {
                double b = double.Parse(tien) * (1 - 0.5);
                txtthanhtien.Text = b.ToString(); ;
            }
            else
            {
                double b = double.Parse(tien);
                txtthanhtien.Text = b.ToString();
            }
        }
       
        private void cbbMaCK_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = txtMaDB.Text;
            string ck = cbbMaCK.SelectedItem.ToString().Trim();
            thanhtien(a, ck);
        }

       

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvDonBan.DataSource = bus.timkiem("DonBan", "MaDB", txtsearch.Text);
            dgvDonBan.Refresh();
            if(txtsearch.Text == "")
            {
                loaddb();
            }    
        }

        private void btntimten_Click(object sender, EventArgs e)
        {
            dgvDonBan.DataSource = bus.timkiem("DonBan", "MaKH", txtsearch.Text);
            dgvDonBan.Refresh();
            if (txtsearch.Text == "")
            {
                loaddb();
            }

        }

        private void txtDonGia_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        public void chinhapso(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }

        private void txtDonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }
    }
}
