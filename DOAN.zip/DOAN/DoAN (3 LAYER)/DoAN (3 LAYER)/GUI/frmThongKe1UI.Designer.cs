﻿namespace DoAN__3_LAYER_.GUI
{
    partial class frmThongKe1UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.listtk = new System.Windows.Forms.GroupBox();
            this.dgvtk = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnThongke = new System.Windows.Forms.Button();
            this.txtngay = new System.Windows.Forms.TextBox();
            this.txtlc = new System.Windows.Forms.Label();
            this.cbbtk = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.listtk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Location = new System.Drawing.Point(1, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(913, 455);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.listtk);
            this.panel4.Location = new System.Drawing.Point(4, 109);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(906, 343);
            this.panel4.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.chart1);
            this.panel6.Location = new System.Drawing.Point(531, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(372, 329);
            this.panel6.TabIndex = 2;
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(3, 6);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(365, 317);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // listtk
            // 
            this.listtk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listtk.BackColor = System.Drawing.Color.White;
            this.listtk.Controls.Add(this.dgvtk);
            this.listtk.Location = new System.Drawing.Point(8, 3);
            this.listtk.Name = "listtk";
            this.listtk.Size = new System.Drawing.Size(516, 323);
            this.listtk.TabIndex = 1;
            this.listtk.TabStop = false;
            this.listtk.Text = "Danh Sách Thống Kê Theo Năm";
            // 
            // dgvtk
            // 
            this.dgvtk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvtk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvtk.BackgroundColor = System.Drawing.Color.White;
            this.dgvtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvtk.Location = new System.Drawing.Point(0, 20);
            this.dgvtk.Name = "dgvtk";
            this.dgvtk.RowHeadersVisible = false;
            this.dgvtk.Size = new System.Drawing.Size(516, 303);
            this.dgvtk.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Turquoise;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(910, 46);
            this.panel2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(318, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thống Kê Doanh Thu";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.btnThongke);
            this.panel5.Controls.Add(this.txtngay);
            this.panel5.Controls.Add(this.txtlc);
            this.panel5.Controls.Add(this.cbbtk);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(8, 55);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(899, 48);
            this.panel5.TabIndex = 0;
            // 
            // btnThongke
            // 
            this.btnThongke.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnThongke.Enabled = false;
            this.btnThongke.Location = new System.Drawing.Point(749, 13);
            this.btnThongke.Name = "btnThongke";
            this.btnThongke.Size = new System.Drawing.Size(75, 23);
            this.btnThongke.TabIndex = 4;
            this.btnThongke.Text = "Thống Kê";
            this.btnThongke.UseVisualStyleBackColor = true;
            this.btnThongke.Click += new System.EventHandler(this.btnThongke_Click);
            // 
            // txtngay
            // 
            this.txtngay.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtngay.Location = new System.Drawing.Point(466, 14);
            this.txtngay.Name = "txtngay";
            this.txtngay.Size = new System.Drawing.Size(100, 20);
            this.txtngay.TabIndex = 3;
            this.txtngay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtngay_KeyPress);
            this.txtngay.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtngay_KeyUp);
            // 
            // txtlc
            // 
            this.txtlc.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtlc.AutoSize = true;
            this.txtlc.Location = new System.Drawing.Point(366, 17);
            this.txtlc.Name = "txtlc";
            this.txtlc.Size = new System.Drawing.Size(82, 13);
            this.txtlc.TabIndex = 2;
            this.txtlc.Text = "Thống Kê Theo";
            // 
            // cbbtk
            // 
            this.cbbtk.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cbbtk.FormattingEnabled = true;
            this.cbbtk.Items.AddRange(new object[] {
            "Ngày ",
            "Tháng ",
            "Năm"});
            this.cbbtk.Location = new System.Drawing.Point(113, 14);
            this.cbbtk.Name = "cbbtk";
            this.cbbtk.Size = new System.Drawing.Size(121, 21);
            this.cbbtk.TabIndex = 1;
            this.cbbtk.SelectedIndexChanged += new System.EventHandler(this.cbbtk_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Thống Kê Theo";
            // 
            // frmThongKe1UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 461);
            this.Controls.Add(this.panel3);
            this.Name = "frmThongKe1UI";
            this.Text = "frmThongKe1UI";
            this.Load += new System.EventHandler(this.frmThongKe1UI_Load);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.listtk.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvtk)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cbbtk;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThongke;
        private System.Windows.Forms.TextBox txtngay;
        private System.Windows.Forms.Label txtlc;
        private System.Windows.Forms.GroupBox listtk;
        private System.Windows.Forms.DataGridView dgvtk;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}