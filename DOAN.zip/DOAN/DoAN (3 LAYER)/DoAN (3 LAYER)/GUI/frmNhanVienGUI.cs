﻿
using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmNhanVienGUI : Form
    {
        public frmNhanVienGUI()
        {
            InitializeComponent();
        }
        NhanVienDTO NV=new NhanVienDTO();
        NhanVienBUS bus=new NhanVienBUS();
        void lammoi()
        {
            foreach (Control ctrl in TTNV.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
                mtbSDT.Text = "";
            }
           
            TTNV.Enabled = true;
            txtMaNV.Enabled = true;
        }
    
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string ma = txtMaNV.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa nhân viên  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa nhân viên  Thành Công !");
                    dgvNhanVien.DataSource = bus.load("NhanVien"); // refresh datagridview
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa nhân viên thất bại !");

            }
        }

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            lammoi();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            BIEN();
          

            bool kt = bus.them(NV);
            if (kt)
            {
                MessageBox.Show("Thêm khách hàng thành công ! ");
                dgvNhanVien.DataSource = bus.load("NhanVien");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã nhân viên  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
            }
        }
       
        void BIEN()
        {
            NV.MaNV = txtMaNV.Text;
            NV.TenNV = txtTenNV.Text;
            NV.GT = txtGT.Text;
            NV.NgaySinh = DateTime.Parse(dtpNgaySinh.Value.ToString("yyyy-MM-dd"));
            NV.DiaChiNV = txtDiaChi.Text;
            NV.Email = txtEmail.Text;
            NV.SdtNV = mtbSDT.Text;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            BIEN();
            bool kt = bus.sua(NV);
            if (kt)
            {
                MessageBox.Show("sửa Nhân Viên thành công ! ");
                dgvNhanVien.DataSource = bus.load("NhanVien");
                lammoi();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }
        void loadpikn()
        {

            dgvNhanVien.DataSource = bus.loadpkn("MaNV", "NhanVien");
            dgvNhanVien.Columns[0].HeaderText = "Mã nhân viên";
            dgvNhanVien.Columns[1].HeaderText = "Tên nhân viên";
            dgvNhanVien.Columns[2].HeaderText = "Giới Tính";
            dgvNhanVien.Columns[3].HeaderText = "Ngày Sinh";
            dgvNhanVien.Columns[4].HeaderText = "Địa Chỉ";
            dgvNhanVien.Columns[5].HeaderText = "Địa Chỉ";
            dgvNhanVien.Columns[6].HeaderText = "SDT";
        }
        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMaNV.Text = dgvNhanVien[0, i].Value.ToString();
            txtTenNV.Text = dgvNhanVien[1, i].Value.ToString();
            txtGT.Text = dgvNhanVien[2, i].Value.ToString();
            dtpNgaySinh.Text = dgvNhanVien[3, i].Value.ToString();
            txtDiaChi.Text = dgvNhanVien[4, i].Value.ToString();
            txtEmail.Text = dgvNhanVien[5, i].Value.ToString();
            mtbSDT.Text = dgvNhanVien[6, i].Value.ToString();
            txtMaNV.Enabled = false;
        }

        private void frmNhanVienGUI_Load(object sender, EventArgs e)
        {
            dgvNhanVien.DataSource = bus.load("NhanVien");
            loadpikn(); 
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
