﻿
using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmNhaCCGUI : Form
    {
        public frmNhaCCGUI()
        {
            InitializeComponent();
        }
        NhaCCDTO NCC=new NhaCCDTO();
        NhaCCBUS bus=new NhaCCBUS   ();
     

        void lammoi()
        {
            foreach (Control ctrl in TTNCC.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }

            TTNCC.Enabled = true;
            txtMa.Enabled = true;
            mtbSDT.Text = "";
        }

        private void frmNhaCCGUI_Load(object sender, EventArgs e)
        {
            dgvNhaCC.DataSource = bus.load("NhaCC"); // refresh datagridview
            loadpikn();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }
        void bien()
        {
            NCC.MaNCC = txtMa.Text;
            NCC.HoTenCC = txtTen.Text;
            NCC.DiaChicc = txtDiaCHi.Text;
            NCC.SDTcc = mtbSDT.Text;
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            string ma = txtMa.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa nhà cung cấp  này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa nhà cung cấp  Thành Công !");
                    dgvNhaCC.DataSource = bus.load("NhaCC");
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa nhà cung cấp thất bại !");

            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.them(NCC);
            if (kt)
            {
                MessageBox.Show("Thêm Nhà cung cấp thành công ! ");
                dgvNhaCC.DataSource = bus.load("NhaCC");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã nhà cc  Đã Tồn tại hoặc bạn chưa điền đủ thông tin ! ");
            }
        }
        void loadpikn()
        {

            dgvNhaCC.DataSource = bus.loadpkn("NhaCC", "MaNCC");
            dgvNhaCC.Columns[0].HeaderText = "Mã nhà cung cấp";
            dgvNhaCC.Columns[1].HeaderText = "Tên nhà cung cấp";
            dgvNhaCC.Columns[2].HeaderText = "Địa Chỉ";
            dgvNhaCC.Columns[3].HeaderText = "SDT";
        }
        private void btnSua_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.sua(NCC);
            if (kt)
            {
                MessageBox.Show("sửa NhÀ cung cấp thành công ! ");
                dgvNhaCC.DataSource = bus.load("NhaCC"); lammoi();

            }
            else
            {
                MessageBox.Show("Sửa thông tin không thành công ! ");
            }
        }

        private void dgvNhaCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMa.Text = dgvNhaCC[0, i].Value.ToString();
            txtTen.Text = dgvNhaCC[1, i].Value.ToString();
            txtDiaCHi.Text = dgvNhaCC[2, i].Value.ToString();
            mtbSDT.Text = dgvNhaCC[3, i].Value.ToString();
            txtMa.Enabled = false;
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvNhaCC.DataSource = bus.timkiem("NhaCC", "MaNCC", txtsearch.Text);
            dgvNhaCC.Refresh();
            if(txtsearch.Text=="")
            {
                dgvNhaCC.DataSource = bus.load("NhaCC");
            }    
        }
    }
}
