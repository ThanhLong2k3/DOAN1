﻿
using DoAN__3_LAYER_.BUS;
using DoAN__3_LAYER_.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmKhachHangGUI : Form
    {
        public frmKhachHangGUI()
        {
            InitializeComponent();
        }

        KhachHangDTO KH=new KhachHangDTO();
        KhachHangBUS bus=new KhachHangBUS();
        
       
        private void dgvKH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i == -1) return;
            txtMa.Text = dgvKH[0, i].Value.ToString();
            txtTen.Text = dgvKH[1, i].Value.ToString();
            txtDiaCHi.Text = dgvKH[2, i].Value.ToString();
            txtemail.Text = dgvKH[3, i].Value.ToString();
            txtSDT.Text = dgvKH[4, i].Value.ToString();
            txtMa.Enabled = false;
        }

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            lammoi();
        }
        void lammoi()
        {
            foreach (Control ctrl in groupBox1.Controls)
            {
                if (ctrl is TextBox)
                {
                    (ctrl as TextBox).Text = "";
                }
                if (ctrl is ComboBox)
                {
                    (ctrl as ComboBox).Text = "";
                }
            }
            txtSDT.Text = "";
            groupBox1.Enabled = true;
            txtMa.Enabled = true;
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r;

            r = MessageBox.Show("Bạn có muốn thoát ?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Close();
            }
        }

        void bien()
        {
            KH.MaKH = txtMa.Text;
            KH.TenKH = txtTen.Text;
            KH.DiaChiKH = txtDiaCHi.Text;
            KH.EmailKH = txtemail.Text;
            KH.SdtKH = txtSDT.Text;
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.them(KH);
            if (kt)
            {
                MessageBox.Show("Thêm khách hàng thành công ! ");
                dgvKH.DataSource = bus.load("KhachHang");
                lammoi();

            }
            else
            {
                MessageBox.Show("mã khách hàng Đã Tồn tại hoặc bạn chưa điền thông tin khách hàng ! ");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            bien();
            bool kt = bus.sua(KH);
            if (kt)
            {
                MessageBox.Show("sửa khách hàng thành công ! ");
                dgvKH.DataSource = bus.load("KhachHang"); 
                lammoi();

            }
            else
            {
                MessageBox.Show("mã khách hàng Đã Tồn tại hoặc bạn chưa điền thông tin khách hàng ! ");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string ma = txtMa.Text;
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muố xóa sản phẩm này ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {


                bool kt = bus.xoa(ma);
                if (kt)
                {
                    MessageBox.Show("Xóa khách hàng Thành Công !");
                    dgvKH.DataSource = bus.load("KhachHang"); // refresh datagridview
                    lammoi();

                }
                else
                    MessageBox.Show("Xóa khách hàng thất bại !");

            }
        }
        void loadphikn()
        {
            dgvKH.DataSource= bus.loadpkn("MaKH","KhachHang");
            dgvKH.Columns[0].HeaderText = "Mã Khách Hàng";
            dgvKH.Columns[1].HeaderText = "Tên Khách Hàng";
            dgvKH.Columns[2].HeaderText = "Địa Chỉ";
            dgvKH.Columns[3].HeaderText = "Email";
            dgvKH.Columns[4].HeaderText = "Số điện thoại";
           
        }

        private void frmKhachHangGUI_Load(object sender, EventArgs e)
        {
            dgvKH.DataSource = bus.load("KhachHang");
            loadphikn();
        }
        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            dgvKH.DataSource = bus.timkiem("KhachHang", "MaKH", txtsearch.Text);
            dgvKH.Refresh();
            if(txtsearch.Text=="")
            {
                dgvKH.DataSource = bus.load("KhachHang");
            }    
        }
    }
}

