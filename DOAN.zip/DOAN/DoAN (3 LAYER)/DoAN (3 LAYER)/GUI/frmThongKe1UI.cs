﻿using DoAN__3_LAYER_.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAN__3_LAYER_.GUI
{
    public partial class frmThongKe1UI : Form
    {
        public frmThongKe1UI()
        {
            InitializeComponent();
        }
        ThongKeBUS bus = new ThongKeBUS();

        private void cbbtk_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string a = cbbtk.SelectedItem.ToString().Trim().ToLower();

            if (txtngay.Text == "")
            {

            }
            if (a == "Ngày".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Ngày";
                
                txtlc.Text = "Nhập Ngày: ";

            }
            else if (a == "Tháng".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Tháng";
                txtlc.Text = "Nhập Tháng: ";


            }
            else if (a == "Năm".Trim().ToLower())
            {
                listtk.Text = "Thống Kê Doanh Thu Theo Năm";

                txtlc.Text = "Nhập Năm: ";

            }
        }

      
        string tk;
        
        private void btnThongke_Click(object sender, EventArgs e)
        {
            
            int ngay = int.Parse(txtngay.Text);
            if (txtngay.Text == "")
            {
                txtngay.Text = "1";
            }
            else
            {
                switch (txtlc.Text)
                {

                    case "Nhập Ngày: ":
                        {
                            tk = "Day";
                            if (ngay > 0 && ngay <= 31)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show("Bạn nhập ngày không dúng vui lòng nhập lại! "); }
                            break;
                        }
                    case "Nhập Tháng: ":
                        {
                            tk = "month";
                            if (ngay > 0 && ngay <= 12)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show("Bạn nhập tháng không dúng vui lòng nhập lại! "); }
                            break;
                        }
                    case "Nhập Năm: ":
                        {
                            tk = "year";
                            string c = DateTime.Now.Year.ToString();
                            if (ngay > 2000 && ngay <= DateTime.Now.Year)
                            {
                                dgvtk.DataSource = bus.thongke(tk, ngay.ToString());
                            }
                            else { MessageBox.Show($"Bạn nhập Năm không hợp lệ vui lòng nhập lại!  2000< năm < {c} "); }
                            break;
                        }
                }
              
            }

        }

        private void frmThongKe1UI_Load(object sender, EventArgs e)
        {
            dgvtk.DataSource = bus.thongke("year",(DateTime.Now.Year).ToString());
            DataTable top5 = bus.GetTop5MaDia("year","2023");
            chart1.DataSource = top5;
            chart1.Series["Series1"].XValueMember = "MaDia";
            chart1.Series["Series1"].YValueMembers = "SLBan";
        }

        private void txtngay_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtngay.Text == "") { btnThongke.Enabled = false; }
            else
            {
                btnThongke.Enabled = true;
            }
        }

        public void chinhapso(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }
        private void txtngay_KeyPress(object sender, KeyPressEventArgs e)
        {
            chinhapso(e);
        }
    }
}
